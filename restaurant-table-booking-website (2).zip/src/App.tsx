import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Menu from "./components/Menu";
import BookingForm from "./components/Booking";
import Contact from "./components/Contact";
import AdminPanel from "./components/AdminPanel";
import DevCenter from "./components/DevCenter";
import Auth from "./components/Auth";
import LoginRequired from "./components/LoginRequired";
import { Booking } from "./types";
import { UtensilsCrossed, Mail, Phone, MapPin } from "lucide-react";

const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 1,
    name: "Arjun Sharma",
    email: "arjun@example.com",
    phone: "+919876543210",
    people: 4,
    date: new Date(Date.now() + 86400000 * 2).toISOString().split("T")[0],
    time: "19:30",
    tableLocation: "Maharajah Booth",
    tableNumber: 9,
    createdAt: new Date().toLocaleDateString()
  },
  {
    id: 2,
    name: "Priya Nair",
    email: "priya@example.com",
    phone: "+919812345678",
    people: 2,
    date: new Date(Date.now() + 86400000 * 3).toISOString().split("T")[0],
    time: "20:30",
    tableLocation: "Haveli Courtyard",
    tableNumber: 5,
    createdAt: new Date().toLocaleDateString()
  },
  {
    id: 3,
    name: "Rohan Malhotra",
    email: "rohan@example.com",
    phone: "+919988776655",
    people: 6,
    date: new Date(Date.now() + 86400000 * 5).toISOString().split("T")[0],
    time: "18:15",
    tableLocation: "Royal Durbar",
    tableNumber: 1,
    createdAt: new Date().toLocaleDateString()
  }
];

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>("home");
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [executedQueries, setExecutedQueries] = useState<string[]>([]);
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);

  // User Auth State
  const [currentUser, setCurrentUser] = useState<{ name: string; email: string; phone: string; role: 'customer' | 'admin' } | null>(null);

  // Track where user wants to go after login
  const [redirectAfterLogin, setRedirectAfterLogin] = useState<string | null>(null);

  // Load and seed bookings
  useEffect(() => {
    const saved = localStorage.getItem("shahi_bookings");
    if (saved) {
      setBookings(JSON.parse(saved));
    } else {
      localStorage.setItem("shahi_bookings", JSON.stringify(INITIAL_BOOKINGS));
      setBookings(INITIAL_BOOKINGS);
    }

    // Load active session if any
    const savedUser = localStorage.getItem("shahi_user");
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  // Save bookings to localStorage
  const saveBookings = (newBookings: Booking[]) => {
    localStorage.setItem("shahi_bookings", JSON.stringify(newBookings));
    setBookings(newBookings);
  };

  // Navigation handler with login check
  const navigateTo = (page: string) => {
    // Pages that require login
    const protectedPages = ["booking"];
    
    if (protectedPages.includes(page) && !currentUser) {
      // Save where user wanted to go
      setRedirectAfterLogin("booking");
      // Show login required page instead
      setCurrentPage("loginRequired");
      return;
    }
    
    setRedirectAfterLogin(null);
    setCurrentPage(page);
  };

  // User Action Handlers
  const handleLoginSuccess = (user: { name: string; email: string; phone: string; role: 'customer' | 'admin' }) => {
    setCurrentUser(user);
    localStorage.setItem("shahi_user", JSON.stringify(user));
    
    // Redirect to the page user originally wanted after login
    if (redirectAfterLogin) {
      setCurrentPage(redirectAfterLogin);
      setRedirectAfterLogin(null);
    } else {
      setCurrentPage("home");
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("shahi_user");
    setRedirectAfterLogin(null);
    setCurrentPage("home");
  };

  // Add Booking
  const handleAddBooking = (bookingData: Omit<Booking, "id" | "createdAt" | "tableNumber">): Booking => {
    const nextId = bookings.length > 0 ? Math.max(...bookings.map((b) => b.id)) + 1 : 1;
    const tableNum = Math.floor(Math.random() * 18) + 1;
    
    const newBooking: Booking = {
      ...bookingData,
      id: nextId,
      tableNumber: tableNum,
      createdAt: new Date().toLocaleDateString()
    };

    const updated = [newBooking, ...bookings];
    saveBookings(updated);
    return newBooking;
  };

  // Delete Booking
  const handleDeleteBooking = (id: number) => {
    const updated = bookings.filter((b) => b.id !== id);
    saveBookings(updated);
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setNewsletterSuccess(true);
    setNewsletterEmail("");
    setTimeout(() => setNewsletterSuccess(false), 5000);
  };

  // Render correct page view
  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <Home setCurrentPage={navigateTo} />;
      case "menu":
        return <Menu setCurrentPage={navigateTo} />;
      case "booking":
        if (!currentUser) {
          setRedirectAfterLogin("booking");
          return <LoginRequired setCurrentPage={navigateTo} />;
        }
        return (
          <BookingForm 
            onAddBooking={handleAddBooking} 
            setExecutedQueries={setExecutedQueries}
            currentUser={currentUser}
          />
        );
      case "contact":
        return <Contact />;
      case "auth":
        return (
          <Auth 
            onLoginSuccess={handleLoginSuccess} 
            setCurrentPage={navigateTo}
            redirectTo={redirectAfterLogin}
          />
        );
      case "loginRequired":
        return <LoginRequired setCurrentPage={navigateTo} />;
      case "admin":
        return (
          <AdminPanel 
            bookings={bookings} 
            onDeleteBooking={handleDeleteBooking} 
            onAddBooking={handleAddBooking}
            setExecutedQueries={setExecutedQueries} 
          />
        );
      case "dev":
        return (
          <DevCenter 
            bookings={bookings} 
            executedQueries={executedQueries} 
          />
        );
      default:
        return <Home setCurrentPage={navigateTo} />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#041510] text-[#fbf8f3] selection:bg-[#d97706] selection:text-[#041510]">
      
      {/* Sticky Navbar */}
      <Navbar 
        currentPage={currentPage} 
        setCurrentPage={navigateTo} 
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* Main Page Content */}
      <main className="flex-grow">
        {renderPage()}
      </main>

      {/* Modern Premium Footer */}
      <footer className="bg-[#02110c] border-t border-[#d97706]/15 text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
            
            {/* Column 1: Brand (4 cols) */}
            <div className="lg:col-span-4 space-y-6">
              <div className="flex items-center space-x-3 cursor-pointer" onClick={() => navigateTo("home")}>
                <div className="bg-[#d97706] text-[#041510] p-2.5 rounded-xl shadow-md">
                  <UtensilsCrossed className="h-5 w-5" />
                </div>
                <div>
                  <span className="text-xl font-black tracking-wider text-white">SHAHI RASOI</span>
                  <span className="text-[9px] block font-semibold text-[#f59e0b] tracking-widest uppercase">
                    Imperial Indian Dining
                  </span>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-light">
                Experience majestic Mughlai curries, Nawabi charcoal tandoor grills, and classical southern delicacies cooked using centuries-old heritage methods. Reserve your courtyard table today.
              </p>
              
              {/* Social links */}
              <div className="flex space-x-4">
                <a href="#facebook" className="bg-[#041510] p-2.5 rounded-xl border border-[#d97706]/15 hover:border-[#d97706]/40 hover:text-amber-500 transition-all">
                  <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                    <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/>
                  </svg>
                </a>
                <a href="#instagram" className="bg-[#041510] p-2.5 rounded-xl border border-[#d97706]/15 hover:border-[#d97706]/40 hover:text-amber-500 transition-all">
                  <svg className="h-4 w-4 stroke-current fill-none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24">
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                  </svg>
                </a>
                <a href="#twitter" className="bg-[#041510] p-2.5 rounded-xl border border-[#d97706]/15 hover:border-[#d97706]/40 hover:text-amber-500 transition-all">
                  <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                </a>
              </div>
            </div>

            {/* Column 2: Quick Links (2 cols) */}
            <div className="lg:col-span-2 space-y-4">
              <h4 className="text-white font-bold text-sm uppercase tracking-wider">Navigation</h4>
              <ul className="space-y-2 text-xs sm:text-sm">
                <li>
                  <button onClick={() => navigateTo("home")} className="hover:text-[#f59e0b] transition-colors cursor-pointer">
                    Home Story
                  </button>
                </li>
                <li>
                  <button onClick={() => navigateTo("menu")} className="hover:text-[#f59e0b] transition-colors cursor-pointer">
                    Shahi Menu
                  </button>
                </li>
                <li>
                  <button onClick={() => navigateTo("booking")} className="hover:text-[#f59e0b] transition-colors cursor-pointer">
                    Book Table
                  </button>
                </li>
                <li>
                  <button onClick={() => navigateTo("contact")} className="hover:text-[#f59e0b] transition-colors cursor-pointer">
                    Contact Us
                  </button>
                </li>
                {currentUser?.role === "admin" && (
                  <>
                    <li>
                      <button onClick={() => navigateTo("admin")} className="hover:text-[#f59e0b] transition-colors cursor-pointer">
                        Admin Panel
                      </button>
                    </li>
                    <li>
                      <button onClick={() => navigateTo("dev")} className="hover:text-[#f59e0b] transition-colors cursor-pointer text-left">
                        XAMPP Code Exporter
                      </button>
                    </li>
                  </>
                )}
              </ul>
            </div>

            {/* Column 3: Contact Details (3 cols) */}
            <div className="lg:col-span-3 space-y-4">
              <h4 className="text-white font-bold text-sm uppercase tracking-wider">Contact Info</h4>
              <ul className="space-y-3.5 text-xs sm:text-sm">
                <li className="flex items-start space-x-2.5">
                  <MapPin className="h-4 w-4 text-[#f59e0b] flex-shrink-0 mt-0.5" />
                  <span className="font-light">Saffron Court, Connaught Place, New Delhi 110001</span>
                </li>
                <li className="flex items-center space-x-2.5">
                  <Phone className="h-4 w-4 text-[#f59e0b] flex-shrink-0" />
                  <span className="font-mono">+91 98765 43210</span>
                </li>
                <li className="flex items-center space-x-2.5">
                  <Mail className="h-4 w-4 text-[#f59e0b] flex-shrink-0" />
                  <span className="font-light">royal@shahirasoi.com</span>
                </li>
              </ul>
            </div>

            {/* Column 4: Newsletter (3 cols) */}
            <div className="lg:col-span-3 space-y-4">
              <h4 className="text-white font-bold text-sm uppercase tracking-wider">Newsletter</h4>
              <p className="text-xs text-slate-400 leading-relaxed font-light">
                Subscribe to get invitations to exclusive tasting dinners, secret wine releases, and chef events.
              </p>
              
              <form onSubmit={handleNewsletterSubmit} className="space-y-2">
                <input
                  type="email"
                  placeholder="enter email address"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="w-full bg-[#041510] border border-[#d97706]/15 text-xs text-white rounded-xl py-2 px-3 focus:outline-none focus:border-[#d97706]"
                />
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-bold text-xs py-2 rounded-xl transition-all cursor-pointer"
                >
                  Subscribe
                </button>
              </form>

              {newsletterSuccess && (
                <p className="text-[10px] text-emerald-400 font-medium">Successfully subscribed! Check your inbox soon.</p>
              )}
            </div>

          </div>

          <div className="border-t border-[#d97706]/15 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center text-xs">
            <p>&copy; {new Date().getFullYear()} Shahi Rasoi Ristorante. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 sm:mt-0">
              <a href="#privacy" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#terms" className="hover:text-white transition-colors">Terms of Service</a>
              {currentUser?.role === "admin" && (
                <button onClick={() => navigateTo("dev")} className="text-[#f59e0b] hover:text-[#fcd34d] font-bold cursor-pointer">XAMPP Dev Suite</button>
              )}
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
