import { useState } from "react";
import { Sparkles, Utensils, Award, Flame, Search, Heart } from "lucide-react";
import { MenuItem } from "../types";

const INDIAN_MENU: MenuItem[] = [
  // STREET FOOD
  {
    id: 12,
    name: "Delhi Shahi Pani Puri (Golgappe)",
    price: 120,
    category: "streetfood",
    description: "8 pieces of hollow crisp fried puris filled with a mixture of spiced potatoes, black chickpeas, sweet tamarind chutney, and freshly made ice-cold mint water.",
    tag: "Chaat Special",
    image: "https://images.pexels.com/photos/17050759/pexels-photo-17050759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 13,
    name: "Chowpatty Pav Bhaji Royale",
    price: 180,
    category: "streetfood",
    description: "Thick spiced mashed vegetable gravy cooked with real butter on a flat griddle, garnished with chopped onions and lemon, served with soft butter-toasted pav buns.",
    tag: "Mumbai Classic",
    image: "https://images.pexels.com/photos/30858402/pexels-photo-30858402.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 14,
    name: "Amritsari Chole Bhature",
    price: 220,
    category: "streetfood",
    description: "Fluffy, deep-fried leavened sourdough bread (Bhature) paired with spicy, rich chickpea curry (Chole) cooked in local punjabi spices, served with pickles.",
    tag: "Rich & Spicy",
    image: "https://images.pexels.com/photos/29173093/pexels-photo-29173093.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 15,
    name: "Khau Galli Vada Pav Duo",
    price: 110,
    category: "streetfood",
    description: "The pride of Maharashtra: Spicy deep-fried garlic mashed potato dumplings encased in golden gram-flour batter, nestled in fluffy buns with green chilies.",
    tag: "Popular Quick Bite",
    image: "https://images.pexels.com/photos/29173119/pexels-photo-29173119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 16,
    name: "Saffron Raj Kachori",
    price: 160,
    category: "streetfood",
    description: "An ultimate king-sized crisp kachori shell stuffed with sprout beans, potato cubes, thick whipped sweet yogurt, pomegranate pearls, fine sev, and mint-tamarind dressings.",
    tag: "Imperial Street Feast",
    image: "https://images.pexels.com/photos/30858402/pexels-photo-30858402.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  // STARTERS
  {
    id: 1,
    name: "Saffron Paneer Tikka",
    price: 320,
    category: "starters",
    description: "Cottage cheese chunks marinated in organic saffron, hung curd, ginger, garlic paste and grilled over slow-burning tandoori charcoal.",
    tag: "Tandoori Special",
    image: "https://images.pexels.com/photos/29173093/pexels-photo-29173093.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 2,
    name: "Amritsari Fish Fry",
    price: 390,
    category: "starters",
    description: "Crisp batter-fried fish fillets infused with carom seeds, ground red chilies, gram flour, and fresh lemon juice.",
    tag: "Punjabi Classic",
    image: "https://images.pexels.com/photos/29173119/pexels-photo-29173119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 3,
    name: "Classic Samosa Chaat",
    price: 180,
    category: "starters",
    description: "Crushed potato samosas topped with warm spiced chickpeas, sweet tamarind chutney, spicy mint yogurt, and fine sev.",
    tag: "Street Food Delight",
    image: "https://images.pexels.com/photos/17050759/pexels-photo-17050759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  // MAINS
  {
    id: 4,
    name: "Paneer Butter Masala",
    price: 250,
    category: "mains",
    description: "Rich and creamy dish of paneer cooked in a velvety tomato, butter, and cashew nut gravy, garnished with dried fenugreek leaves.",
    tag: "All-Time Favorite",
    image: "https://images.pexels.com/photos/30858402/pexels-photo-30858402.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 5,
    name: "Hyderabadi Chicken Biryani",
    price: 300,
    category: "mains",
    description: "Fragrant, long-grain basmati rice and tender chicken pieces slow-cooked with fresh mint, coriander, and authentic Nizam secret spices under dum.",
    tag: "Chef's Masterpiece",
    image: "https://images.pexels.com/photos/17050759/pexels-photo-17050759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 6,
    name: "Dal Makhani Bukharas",
    price: 240,
    category: "mains",
    description: "Whole black lentils and red kidney beans slow-cooked over wood charcoal for 18 hours with fresh cream, unsalted butter, and organic tomato puree.",
    tag: "Legendary Slow Cook",
    image: "https://images.pexels.com/photos/29173093/pexels-photo-29173093.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 7,
    name: "Mughlai Korma Curry",
    price: 420,
    category: "mains",
    description: "Rich, mildly spiced mutton curry prepared with hand-ground almonds, yogurt, saffron strands, and a splash of kewra water.",
    tag: "Imperial Royal Feast",
    image: "https://images.pexels.com/photos/29173119/pexels-photo-29173119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  // DESSERTS
  {
    id: 8,
    name: "Royal Gulab Jamun",
    price: 150,
    category: "desserts",
    description: "Warm, sweet milk-solid spheres deep fried and soaked in delicate green cardamom, rose water, and saffron-scented sugar syrup.",
    tag: "Traditional Sweet",
    image: "https://images.pexels.com/photos/29173119/pexels-photo-29173119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 9,
    name: "Kashmiri Kesar Kulfi",
    price: 170,
    category: "desserts",
    description: "Traditional Indian slow-churned condensed milk ice cream flavored with saffron, cardamom, pistachio nuts, and almond flakes.",
    tag: "Frozen Delight",
    image: "https://images.pexels.com/photos/30858402/pexels-photo-30858402.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  // DRINKS
  {
    id: 10,
    name: "Mango Lassi Royale",
    price: 120,
    category: "drinks",
    description: "Refreshing thick yogurt shake blended with sweet Alphonso mango pulp, saffron, cardamom powder, and topped with almond slivers.",
    tag: "House Special Drink",
    image: "https://images.pexels.com/photos/17050759/pexels-photo-17050759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  },
  {
    id: 11,
    name: "Masala Chai",
    price: 80,
    category: "drinks",
    description: "Freshly brewed Assam tea leaves simmered with milk, ginger, crushed green cardamom, cinnamon cloves, and black pepper.",
    tag: "Indian Elixir",
    image: "https://images.pexels.com/photos/29173093/pexels-photo-29173093.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=500"
  }
];

export default function Menu({ setCurrentPage }: { setCurrentPage: (page: string) => void }) {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'streetfood' | 'starters' | 'mains' | 'desserts' | 'drinks'>('all');
  const [search, setSearch] = useState("");
  const [likedItems, setLikedItems] = useState<number[]>([]);

  const handleLike = (id: number) => {
    if (likedItems.includes(id)) {
      setLikedItems(likedItems.filter((item) => item !== id));
    } else {
      setLikedItems([...likedItems, id]);
    }
  };

  const filteredItems = INDIAN_MENU.filter((item) => {
    const matchesCategory = selectedCategory === 'all' ? true : item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase()) || 
                          item.description.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="bg-[#041510] text-[#fbf8f3] min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header Title */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center space-x-2 bg-[#d97706]/10 text-[#f59e0b] px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest border border-[#d97706]/20">
            <Award className="h-4 w-4" />
            <span>The Shahi Kitchen - Culinary Jewels</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white mt-3">Royal Feast Menu</h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-2 font-light">
            Indulge in our exquisite street food delicacies, aromatic charcoal grills, and velvety slow-cooked curries crafted meticulously by our master chefs.
          </p>
        </div>

        {/* SEARCH AND FILTER BUTTONS */}
        <div className="space-y-6 max-w-5xl mx-auto mb-12">
          
          {/* Search bar */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search dishes (e.g. Pani Puri, Chole Bhature, Biryani...)"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[#02110c] border border-[#d97706]/20 rounded-xl py-3 pl-10 pr-4 text-xs sm:text-sm text-white placeholder-slate-600 focus:outline-none focus:border-[#d97706] transition-colors"
            />
          </div>

          {/* Categories Tab selector */}
          <div className="flex flex-wrap justify-center gap-2">
            {(['all', 'streetfood', 'starters', 'mains', 'desserts', 'drinks'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider border cursor-pointer transition-all ${
                  selectedCategory === cat
                    ? "bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] border-transparent shadow-md"
                    : "bg-[#07241b] border-[#d97706]/10 text-slate-300 hover:bg-[#0c3528]"
                }`}
              >
                {cat === 'all' ? 'Full Feast' : cat === 'streetfood' ? 'Street Food 🍢' : cat === 'mains' ? 'Main Course' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* MENU CARD GRID */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {filteredItems.map((item) => (
              <div 
                key={item.id}
                className="bg-[#02110c] rounded-2xl border border-[#d97706]/10 hover:border-[#d97706]/35 overflow-hidden transition-all duration-300 flex flex-col justify-between shadow-xl group"
              >
                <div className="relative overflow-hidden h-52">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {item.tag && (
                    <span className="absolute top-3 left-3 bg-[#d97706] text-[#041510] text-[10px] uppercase tracking-widest font-black px-2.5 py-1 rounded-md">
                      {item.tag}
                    </span>
                  )}

                  {/* Favorite Button */}
                  <button 
                    onClick={() => handleLike(item.id)}
                    className="absolute top-3 right-3 bg-[#041510]/80 p-2 rounded-xl border border-[#d97706]/10 hover:border-[#d97706]/30 transition-all cursor-pointer"
                  >
                    <Heart className={`h-4 w-4 ${likedItems.includes(item.id) ? "fill-rose-500 text-rose-500" : "text-slate-400"}`} />
                  </button>
                  
                  {/* Spice Level Indicator for Starters/Mains/Streetfood */}
                  {(item.category === "starters" || item.category === "mains" || item.category === "streetfood") && (
                    <div className="absolute bottom-3 left-3 bg-[#041510]/95 p-1.5 rounded-lg flex items-center space-x-0.5 border border-[#d97706]/20">
                      <Flame className="h-4.5 w-4.5 text-[#d97706] fill-current" />
                      <span className="text-[9px] font-black uppercase tracking-wider text-[#f59e0b] pr-1">Medium Spice</span>
                    </div>
                  )}
                  
                  <span className="absolute bottom-3 right-3 bg-[#041510]/95 border border-[#d97706]/20 text-[#f59e0b] font-black text-sm px-3 py-1 rounded-lg">
                    ₹{item.price}
                  </span>
                </div>

                <div className="p-5 flex-grow flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex justify-between items-start gap-2">
                      <h3 className="font-bold text-lg text-white group-hover:text-[#f59e0b] transition-colors leading-snug">
                        {item.name}
                      </h3>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed font-light">
                      {item.description}
                    </p>
                  </div>

                  <div className="pt-4 mt-4 border-t border-[#07241b] flex justify-between items-center text-xs">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-[#f59e0b]">
                      {item.category === "mains" ? "Main Course" : item.category === "streetfood" ? "Street Food 🍢" : item.category}
                    </span>
                    <button
                      onClick={() => setCurrentPage("booking")}
                      className="bg-[#07241b] border border-[#d97706]/20 hover:bg-[#d97706]/10 text-[#f59e0b] font-bold px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1 cursor-pointer text-[11px]"
                    >
                      <Utensils className="h-3.5 w-3.5" />
                      <span>Book Seat To Enjoy</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <Utensils className="h-12 w-12 mx-auto text-slate-600 mb-3" />
            <h3 className="font-bold text-lg text-white">No Dishes Found</h3>
            <p className="text-xs text-slate-400 mt-1">Try adjusting your filters or search keywords.</p>
          </div>
        )}

        {/* Bottom Banner */}
        <div className="max-w-5xl mx-auto mt-16 bg-[#02110c] border border-[#d97706]/20 p-6 sm:p-8 rounded-3xl flex flex-col md:flex-row justify-between items-center gap-6 shadow-xl">
          <div className="space-y-1">
            <h3 className="font-bold text-white text-lg sm:text-xl flex items-center gap-2">
              <Sparkles className="text-[#f59e0b] h-5 w-5" />
              <span>Hosting A Shahi Private Gathering?</span>
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm font-light">
              We provide customized buffet, tandoori grills, and dessert counters for weddings, anniversaries, and corporate events.
            </p>
          </div>
          <button
            onClick={() => setCurrentPage("booking")}
            className="bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black px-6 py-3 rounded-xl hover:brightness-110 transition-all text-xs sm:text-sm whitespace-nowrap cursor-pointer"
          >
            Reserve Large Dining Hall
          </button>
        </div>

      </div>
    </div>
  );
}
