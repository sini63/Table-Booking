import React, { useState } from "react";
import { Search, Trash2, Calendar, Users, SlidersHorizontal, Plus, TrendingUp, Grid, ShieldAlert, CheckCircle } from "lucide-react";
import { Booking } from "../types";

interface AdminPanelProps {
  bookings: Booking[];
  onDeleteBooking: (id: number) => void;
  onAddBooking: (booking: Omit<Booking, "id" | "createdAt" | "tableNumber">) => Booking;
  setExecutedQueries: React.Dispatch<React.SetStateAction<string[]>>;
}

export default function AdminPanel({ bookings, onDeleteBooking, onAddBooking, setExecutedQueries }: AdminPanelProps) {
  // Filters
  const [search, setSearch] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [sizeFilter, setSizeFilter] = useState("");

  // Walk-in form modal/panel
  const [showWalkin, setShowWalkin] = useState(false);
  const [walkinName, setWalkinName] = useState("");
  const [walkinEmail, setWalkinEmail] = useState("");
  const [walkinPhone, setWalkinPhone] = useState("");
  const [walkinPeople] = useState(2);
  const walkinDate = new Date().toISOString().split("T")[0];
  const walkinTime = "19:00";
  const [walkinArea, setWalkinArea] = useState("Maharajah Booth");

  // Calculations
  const totalBookings = bookings.length;
  const totalGuests = bookings.reduce((acc, curr) => acc + curr.people, 0);
  const bookingsToday = bookings.filter(b => b.date === new Date().toISOString().split("T")[0]).length;
  const occupancyRate = Math.min(Math.round((totalGuests / 60) * 100), 100); // 60 is full capacity for simplicity

  // Filter Bookings
  const filteredBookings = bookings.filter((b) => {
    const matchesSearch = 
      b.name.toLowerCase().includes(search.toLowerCase()) || 
      b.email.toLowerCase().includes(search.toLowerCase()) ||
      b.phone.includes(search);
    
    const matchesDate = dateFilter ? b.date === dateFilter : true;
    const matchesSize = sizeFilter ? b.people === parseInt(sizeFilter) : true;

    return matchesSearch && matchesDate && matchesSize;
  });

  // Handle Delete Booking
  const handleDelete = (id: number, name: string) => {
    if (window.confirm(`Are you sure you want to cancel the booking for ${name}?`)) {
      onDeleteBooking(id);

      // Log Delete Query
      const deleteSQL = `PREPARE stmt FROM 'DELETE FROM bookings WHERE id = ?';
SET @id = ${id};
EXECUTE stmt USING @id;
DEALLOCATE PREPARE stmt;`;
      setExecutedQueries((prev) => [deleteSQL, ...prev]);
    }
  };

  // Handle Walkin Submit
  const handleWalkinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!walkinName.trim() || !walkinEmail.trim() || !walkinPhone.trim()) {
      alert("All fields are required.");
      return;
    }

    onAddBooking({
      name: walkinName,
      email: walkinEmail,
      phone: walkinPhone,
      people: walkinPeople,
      date: walkinDate,
      time: walkinTime,
      tableLocation: walkinArea
    });

    // Reset Form
    setWalkinName("");
    setWalkinEmail("");
    setWalkinPhone("");
    setShowWalkin(false);
  };

  return (
    <div className="bg-[#041510] text-[#fbf8f3] min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center space-x-2 text-[#f59e0b]">
              <ShieldAlert className="h-5 w-5" />
              <span className="text-xs font-bold uppercase tracking-widest">Admin Control Center</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white mt-1">Live Bookings Dashboard</h1>
            <p className="text-xs sm:text-sm text-slate-400">Manage real-time seating lists, guest lists, occupancy rates, and walk-ins.</p>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => setShowWalkin(!showWalkin)}
              className="bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black px-5 py-2.5 rounded-xl shadow-lg hover:brightness-110 flex items-center space-x-2 text-sm cursor-pointer transition-all"
            >
              <Plus className="h-4 w-4" />
              <span>Add Shahi Walk-in</span>
            </button>
          </div>
        </div>

        {/* METRICS GRID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#02110c] border border-[#d97706]/10 p-5 rounded-2xl flex items-center justify-between shadow-md">
            <div>
              <span className="text-slate-400 text-xs font-semibold block uppercase tracking-wider">Total Active Bookings</span>
              <span className="text-2xl sm:text-3xl font-black text-white mt-1 block">{totalBookings}</span>
            </div>
            <div className="bg-[#d97706]/10 p-3 rounded-xl border border-[#d97706]/20">
              <Calendar className="h-6 w-6 text-[#f59e0b]" />
            </div>
          </div>

          <div className="bg-[#02110c] border border-[#d97706]/10 p-5 rounded-2xl flex items-center justify-between shadow-md">
            <div>
              <span className="text-slate-400 text-xs font-semibold block uppercase tracking-wider">Total Headcount</span>
              <span className="text-2xl sm:text-3xl font-black text-white mt-1 block">{totalGuests}</span>
            </div>
            <div className="bg-[#d97706]/10 p-3 rounded-xl border border-[#d97706]/20">
              <Users className="h-6 w-6 text-[#f59e0b]" />
            </div>
          </div>

          <div className="bg-[#02110c] border border-[#d97706]/10 p-5 rounded-2xl flex items-center justify-between shadow-md">
            <div>
              <span className="text-slate-400 text-xs font-semibold block uppercase tracking-wider">Bookings Today</span>
              <span className="text-2xl sm:text-3xl font-black text-white mt-1 block">{bookingsToday}</span>
            </div>
            <div className="bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/20">
              <TrendingUp className="h-6 w-6 text-emerald-400" />
            </div>
          </div>

          <div className="bg-[#02110c] border border-[#d97706]/10 p-5 rounded-2xl flex items-center justify-between shadow-md">
            <div>
              <span className="text-slate-400 text-xs font-semibold block uppercase tracking-wider">Chamber Occupancy</span>
              <span className="text-2xl sm:text-3xl font-black text-white mt-1 block">{occupancyRate}%</span>
            </div>
            <div className="bg-[#d97706]/10 p-3 rounded-xl border border-[#d97706]/20">
              <Grid className="h-6 w-6 text-[#f59e0b]" />
            </div>
          </div>
        </div>

        {/* WALK-IN FORM PANELS (CONDITIONAL) */}
        {showWalkin && (
          <div className="bg-[#02110c] border border-[#d97706]/20 rounded-2xl p-6 shadow-xl animate-fadeIn space-y-4 max-w-4xl mx-auto">
            <h3 className="text-lg font-bold text-white border-b border-[#07241b] pb-2">Add Shahi Walk-in (Instant Reservation)</h3>
            <form onSubmit={handleWalkinSubmit} className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">Guest Name</label>
                <input
                  type="text"
                  required
                  placeholder="Karan Johar"
                  value={walkinName}
                  onChange={(e) => setWalkinName(e.target.value)}
                  className="w-full bg-[#041510] border border-[#d97706]/15 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-[#d97706]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="karan@movies.in"
                  value={walkinEmail}
                  onChange={(e) => setWalkinEmail(e.target.value)}
                  className="w-full bg-[#041510] border border-[#d97706]/15 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-[#d97706]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">Indian Mobile</label>
                <input
                  type="tel"
                  required
                  placeholder="+91 9988776655"
                  value={walkinPhone}
                  onChange={(e) => setWalkinPhone(e.target.value)}
                  className="w-full bg-[#041510] border border-[#d97706]/15 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-[#d97706]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">Table Chamber Area</label>
                <select
                  value={walkinArea}
                  onChange={(e) => setWalkinArea(e.target.value)}
                  className="w-full bg-[#041510] border border-[#d97706]/15 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-[#d97706]"
                >
                  <option value="Royal Durbar">Shahi Durbar Hall</option>
                  <option value="Haveli Courtyard">Haveli Courtyard</option>
                  <option value="Maharajah Booth">Maharajah Booths</option>
                  <option value="Saffron Terrace">Saffron Terrace</option>
                </select>
              </div>
              <div className="sm:col-span-4 flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowWalkin(false)}
                  className="bg-[#07241b] hover:bg-[#0c3528] text-slate-400 px-4 py-2 rounded-xl text-xs font-bold border border-[#d97706]/10 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#d97706] hover:bg-[#f59e0b] text-[#041510] font-black px-5 py-2 rounded-xl text-xs cursor-pointer shadow"
                >
                  Save Walk-In Row
                </button>
              </div>
            </form>
          </div>
        )}

        {/* CONTROLS BAR (SEARCH & FILTERS) */}
        <div className="bg-[#02110c] border border-[#d97706]/10 p-5 rounded-2xl flex flex-col md:flex-row gap-4 items-center justify-between shadow-md">
          <div className="relative w-full md:max-w-md">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search by Guest Name, Email, or Phone..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[#041510] border border-[#d97706]/15 rounded-xl py-2.5 pl-10 pr-4 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-[#d97706]"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <div className="flex items-center space-x-1.5 text-xs text-slate-400">
              <SlidersHorizontal className="h-4 w-4" />
              <span>Filters:</span>
            </div>

            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="bg-[#041510] border border-[#d97706]/15 text-xs text-white rounded-xl py-2 px-3 focus:outline-none focus:border-[#d97706]"
            />

            <select
              value={sizeFilter}
              onChange={(e) => setSizeFilter(e.target.value)}
              className="bg-[#041510] border border-[#d97706]/15 text-xs text-white rounded-xl py-2 px-3 focus:outline-none focus:border-[#d97706]"
            >
              <option value="">Any Guest Count</option>
              {Array.from({ length: 10 }, (_, i) => i + 1).map((num) => (
                <option key={num} value={num}>
                  {num} {num === 1 ? "Guest" : "Guests"}
                </option>
              ))}
            </select>

            {(dateFilter || sizeFilter || search) && (
              <button
                onClick={() => {
                  setDateFilter("");
                  setSizeFilter("");
                  setSearch("");
                }}
                className="text-xs text-rose-400 hover:text-white font-bold px-2 py-1 transition-colors cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* BOOKINGS TABLE */}
        <div className="bg-[#02110c] border border-[#d97706]/10 rounded-3xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-[#041510] border-b border-[#07241b] text-slate-400 text-xs font-bold uppercase tracking-wider">
                  <th className="p-4 sm:p-5">Guest Details</th>
                  <th className="p-4 sm:p-5">Contact Details</th>
                  <th className="p-4 sm:p-5">Party Size</th>
                  <th className="p-4 sm:p-5">Seating Details</th>
                  <th className="p-4 sm:p-5">Date & Time</th>
                  <th className="p-4 sm:p-5 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#07241b] text-slate-300 text-xs sm:text-sm">
                {filteredBookings.length > 0 ? (
                  filteredBookings.map((b) => (
                    <tr key={b.id} className="hover:bg-[#07241b]/10 transition-colors">
                      <td className="p-4 sm:p-5">
                        <p className="font-extrabold text-white text-sm sm:text-base">{b.name}</p>
                        <p className="text-[10px] text-slate-500 font-mono mt-0.5">ID: #SH-{b.id + 100}</p>
                      </td>
                      <td className="p-4 sm:p-5 space-y-0.5">
                        <p className="text-slate-300 text-xs sm:text-sm">{b.email}</p>
                        <p className="text-[11px] text-slate-400 font-mono">{b.phone}</p>
                      </td>
                      <td className="p-4 sm:p-5">
                        <span className="bg-[#d97706]/10 text-[#f59e0b] border border-[#d97706]/20 font-black px-3 py-1 rounded-full text-[10px] uppercase tracking-wider">
                          {b.people} Guests
                        </span>
                      </td>
                      <td className="p-4 sm:p-5">
                        <p className="font-bold text-white text-xs sm:text-sm">{b.tableLocation}</p>
                        <p className="text-[11px] text-slate-400 font-semibold mt-0.5">Table #{b.tableNumber}</p>
                      </td>
                      <td className="p-4 sm:p-5 space-y-0.5">
                        <p className="font-bold text-slate-100">{b.date}</p>
                        <p className="text-[11px] text-slate-400 font-mono">{b.time}</p>
                      </td>
                      <td className="p-4 sm:p-5 text-center">
                        <button
                          onClick={() => handleDelete(b.id, b.name)}
                          className="bg-rose-500/10 hover:bg-rose-500 border border-rose-500/20 text-rose-400 hover:text-white p-2.5 rounded-xl transition-all cursor-pointer"
                          title="Delete Booking"
                        >
                          <Trash2 className="h-4.5 w-4.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="text-center py-20 text-slate-500">
                      <Calendar className="h-10 w-10 mx-auto text-slate-600 mb-2" />
                      <p className="font-bold text-sm">No Active Table Reservations Found</p>
                      <p className="text-xs text-slate-400 font-light mt-0.5">Try adjusting your filters or query strings.</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          <div className="bg-[#041510] border-t border-[#07241b] px-6 py-4 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-400 gap-3">
            <span>Showing {filteredBookings.length} of {totalBookings} total booked reservations</span>
            <div className="flex items-center space-x-1.5 text-[10px] bg-[#d97706]/10 text-[#f59e0b] px-2.5 py-1 rounded border border-[#d97706]/35 font-mono uppercase">
              <CheckCircle className="h-3.5 w-3.5" />
              <span>Table limits enforce safety controls (max 10 people)</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
