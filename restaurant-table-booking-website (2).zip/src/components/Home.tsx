import { useState } from "react";
import { Star, Clock, Sparkles, MapPin, Award, ShieldCheck, Heart, ArrowRight } from "lucide-react";
import { MenuItem, Testimonial } from "../types";

interface HomeProps {
  setCurrentPage: (page: string) => void;
}

const SHAHI_SPECIALS: MenuItem[] = [
  {
    id: 1,
    name: "Shahi Paneer Tikka",
    price: 320,
    category: "starters",
    description: "Creamy tandoori cottage cheese cubes marinated in saffron, cardamom, and thick hung curd, grilled to perfection in clay oven.",
    tag: "Tandoori Special",
    image: "https://images.pexels.com/photos/29173093/pexels-photo-29173093.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"
  },
  {
    id: 2,
    name: "Awadhi Dum Biryani",
    price: 450,
    category: "mains",
    description: "Slow-cooked fragrant basmati rice layered with aromatic saffron spices, fried onions, and fresh seasonal vegetables cooked under authentic sealed handi dum.",
    tag: "Signature Dish",
    image: "https://images.pexels.com/photos/17050759/pexels-photo-17050759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"
  },
  {
    id: 3,
    name: "Paneer Tikka Masala",
    price: 380,
    category: "mains",
    description: "Grilled Paneer Tikka chunks simmered in a rich, velvety, spiced tomato, butter, and cashew gravy with a touch of fresh cream and green coriander.",
    tag: "Royal Main Course",
    image: "https://images.pexels.com/photos/30858402/pexels-photo-30858402.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"
  },
  {
    id: 4,
    name: "Shahi Tukda & Gulab Jamun Duo",
    price: 220,
    category: "desserts",
    description: "Golden fried bread soaked in saffron sugar syrup and topped with rich, thick rabri, paired with warm cardamom-infused gulab jamun.",
    tag: "Imperial Sweet",
    image: "https://images.pexels.com/photos/29173119/pexels-photo-29173119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600"
  }
];

const REVIEWS: Testimonial[] = [
  {
    id: 1,
    name: "Rohan Malhotra",
    rating: 5,
    role: "Culinary Editor, Delhi Times",
    comment: "The Saffron-infused Paneer Tikka and Awadhi Dum Biryani transported me directly to Lucknow's royal courts. The booking system and visual courtyard selection is masterfully done!",
    date: "1 day ago"
  },
  {
    id: 2,
    name: "Aishwarya Sen",
    rating: 5,
    role: "Food Blogger & Local Guide",
    comment: "We reserved a Maharajah Booth for our family gathering. Impeccable hospitality, authentic flavors in every bite, and beautiful traditional patterns everywhere.",
    date: "4 days ago"
  },
  {
    id: 3,
    name: "Vikram Rathore",
    rating: 5,
    role: "Mewar Heritage Sommelier",
    comment: "Excellent pairing of classical Indian ragas, elegant lighting, and the best softest buttery naans. A true five-star standard in table reservations and fine-dining.",
    date: "1 week ago"
  }
];

export default function Home({ setCurrentPage }: HomeProps) {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'starters' | 'mains' | 'desserts'>('all');

  const filteredMenu = selectedCategory === 'all' 
    ? SHAHI_SPECIALS 
    : SHAHI_SPECIALS.filter(item => item.category === selectedCategory);

  return (
    <div className="bg-[#041510] text-[#fbf8f3] min-h-screen">
      {/* Royal Hero Section */}
      <div 
        className="relative h-[85vh] flex items-center justify-center bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(4, 21, 16, 0.45) 30%, rgba(4, 21, 16, 0.98) 95%), url('https://images.pexels.com/photos/17050759/pexels-photo-17050759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=2000')`
        }}
      >
        <div className="max-w-5xl mx-auto px-4 text-center z-10 animate-fadeIn">
          <div className="inline-flex items-center space-x-2 bg-[#d97706]/20 border border-[#d97706]/40 text-[#f59e0b] px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest mb-6">
            <Sparkles className="h-4 w-4 text-[#f59e0b]" />
            <span>Saffron & Spice: The Quintessential Indian Experience</span>
          </div>
          
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight mb-6">
            Shahi Rasoi & <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#f59e0b] via-[#fcd34d] to-[#d97706]">
              Royal Banquets
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto mb-10 leading-relaxed font-light">
            Embark on a majestic culinary journey through saffron courtyards, clay tandoors, and hand-ground spices. Experience luxury hospitality fit for kings.
          </p>

          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6">
            <button
              onClick={() => setCurrentPage("booking")}
              className="w-full sm:w-auto bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black px-8 py-4 rounded-xl shadow-xl shadow-[#d97706]/20 hover:from-[#f59e0b] hover:to-[#d97706] transition-all flex items-center justify-center space-x-3 text-base group cursor-pointer"
            >
              <span>Book Royal Table</span>
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => setCurrentPage("menu")}
              className="w-full sm:w-auto bg-[#07241b] border border-[#d97706]/40 hover:bg-[#0c3528] text-white font-bold px-8 py-4 rounded-xl transition-all cursor-pointer"
            >
              Explore Shahi Menu
            </button>
          </div>
        </div>

        {/* Hero Features Bar */}
        <div className="absolute bottom-6 left-0 right-0 hidden md:block z-20">
          <div className="max-w-5xl mx-auto px-4">
            <div className="grid grid-cols-3 gap-6 bg-[#07241b]/95 border border-[#d97706]/20 p-4 rounded-2xl backdrop-blur-md">
              <div className="flex items-center space-x-3 justify-center text-center">
                <Clock className="text-[#f59e0b] h-5 w-5 flex-shrink-0" />
                <span className="text-sm font-semibold">Tandoor Hours: 11:00 AM - 11:00 PM</span>
              </div>
              <div className="flex items-center space-x-3 justify-center border-x border-[#d97706]/20 text-center">
                <MapPin className="text-[#f59e0b] h-5 w-5 flex-shrink-0" />
                <span className="text-sm font-semibold">Delhi, Mumbai & Manhattan</span>
              </div>
              <div className="flex items-center space-x-3 justify-center text-center">
                <Award className="text-[#f59e0b] h-5 w-5 flex-shrink-0" />
                <span className="text-sm font-semibold">Best Traditional Heritage Award</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Traditional Indian Introduction */}
      <section className="py-20 bg-[#041510] relative">
        {/* Decorative traditional border backdrop element */}
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-emerald-600 via-yellow-500 to-orange-600 opacity-50" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Story Image */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-[#d97706]/30 to-transparent rounded-3xl z-10 pointer-events-none" />
              <img 
                src="https://images.pexels.com/photos/29173119/pexels-photo-29173119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1000" 
                alt="Shahi Tandoor Grill at Shahi Rasoi" 
                className="rounded-3xl shadow-2xl object-cover h-[500px] w-full border border-[#d97706]/30"
              />
              <div className="absolute -bottom-6 -right-6 bg-[#07241b] border border-[#d97706]/30 p-6 rounded-2xl hidden sm:flex items-center space-x-4 max-w-xs shadow-xl z-20">
                <div className="bg-[#d97706] p-3 rounded-xl text-[#041510] font-black text-2xl">
                  30+
                </div>
                <div>
                  <h4 className="font-bold text-white">Traditional Spices</h4>
                  <p className="text-xs text-slate-300">Independently roasted & freshly hand-ground every single morning.</p>
                </div>
              </div>
            </div>

            {/* Story Text */}
            <div className="space-y-6">
              <div className="inline-flex items-center space-x-2 bg-[#d97706]/10 text-[#f59e0b] px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
                <Heart className="h-3.5 w-3.5" />
                <span>Our Heritage Story</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-white leading-tight">
                Authentic Royal Gastronomy From The Clay Tandoor
              </h2>
              <p className="text-slate-300 leading-relaxed font-light">
                Welcome to Shahi Rasoi, where legacy cooking meets master modern hospitality. We offer an opulent menu celebrating Mughlai curries, Nawabi tandoors, and classical southern delicacies like crisp, golden Dosas.
              </p>
              <p className="text-slate-300 leading-relaxed font-light">
                Our kitchen utilizes standard heavy clay tandoors heated over live charcoal. This imparts that distinct traditional wood-fired charcoal smoke aroma to every slice of Butter Naan, Paneer Tikka, and spiced Seekh Kebab.
              </p>

              <div className="grid grid-cols-2 gap-6 pt-4">
                <div className="flex items-start space-x-3">
                  <div className="bg-[#d97706]/10 p-2 rounded-lg text-[#f59e0b] border border-[#d97706]/20">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">Saffron Pure</h4>
                    <p className="text-xs text-slate-400">Imported Kashmiri Kesar.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-[#d97706]/10 p-2 rounded-lg text-[#f59e0b] border border-[#d97706]/20">
                    <Award className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">Ghee Sourced Daily</h4>
                    <p className="text-xs text-slate-400">Pure handcrafted organic ghee.</p>
                  </div>
                </div>
              </div>

              <div className="pt-6">
                <button
                  onClick={() => setCurrentPage("booking")}
                  className="bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black px-6 py-3 rounded-xl transition-all shadow-lg hover:brightness-110 cursor-pointer"
                >
                  Book Your Courtyard Table
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Signature Specialties Section */}
      <section id="signature-menu" className="py-20 bg-[#02110c] border-y border-[#d97706]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl sm:text-4xl font-black text-white">Shahi Imperial Specials</h2>
            <p className="text-slate-400 mt-3 font-light">
              Explore our hand-picked curated delicacies prepared daily using organic herbs, whole saffron, and authentic ghee slow-cooking methods.
            </p>

            {/* Filter Buttons */}
            <div className="flex flex-wrap justify-center gap-2 mt-8">
              {(['all', 'starters', 'mains', 'desserts'] as const).map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                    selectedCategory === category
                      ? "bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] shadow-md"
                      : "bg-[#07241b] text-slate-300 hover:bg-[#0c3528] border border-[#d97706]/10"
                  }`}
                >
                  {category === 'all' ? 'All Masterpieces' : category}
                </button>
              ))}
            </div>
          </div>

          {/* Menu Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredMenu.map((item) => (
              <div 
                key={item.id} 
                className="bg-[#041510] rounded-2xl border border-[#d97706]/10 overflow-hidden hover:border-[#d97706]/40 transition-all duration-300 flex flex-col group shadow-lg"
              >
                <div className="relative overflow-hidden h-48">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {item.tag && (
                    <span className="absolute top-3 left-3 bg-[#d97706] text-[#041510] font-black text-[10px] uppercase tracking-widest px-2.5 py-1 rounded-md shadow-md">
                      {item.tag}
                    </span>
                  )}
                  <span className="absolute bottom-3 right-3 bg-[#041510]/95 border border-[#d97706]/20 text-[#f59e0b] font-black text-sm px-3 py-1 rounded-lg">
                    ₹{item.price}
                  </span>
                </div>
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-lg text-white group-hover:text-[#f59e0b] transition-colors">
                      {item.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed font-light">
                      {item.description}
                    </p>
                  </div>
                  <div className="mt-4 pt-4 border-t border-[#07241b] flex justify-between items-center">
                    <span className="text-[10px] font-bold text-[#f59e0b] uppercase tracking-widest">
                      {item.category}
                    </span>
                    <button 
                      onClick={() => setCurrentPage("booking")}
                      className="text-[#f59e0b] text-xs font-bold flex items-center space-x-1 hover:text-[#fcd34d]"
                    >
                      <span>Book to taste</span>
                      <ArrowRight className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Guest Feedbacks */}
      <section className="py-20 bg-[#041510]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-black text-white">What Our Honored Guests Say</h2>
            <p className="text-slate-400 mt-3 font-light">
              Read real reviews from culinary critics, local guides, and food connoisseurs who love our traditional Indian banquet experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {REVIEWS.map((review) => (
              <div 
                key={review.id} 
                className="bg-[#02110c] border border-[#d97706]/10 p-6 rounded-2xl relative flex flex-col justify-between shadow-lg"
              >
                <div>
                  <div className="flex items-center space-x-1 text-[#f59e0b] mb-4">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-slate-300 italic text-sm leading-relaxed mb-6 font-light">
                    "{review.comment}"
                  </p>
                </div>
                <div className="flex justify-between items-center border-t border-[#07241b] pt-4">
                  <div>
                    <h4 className="font-bold text-white text-sm">{review.name}</h4>
                    <p className="text-xs text-slate-400 font-light">{review.role}</p>
                  </div>
                  <span className="text-xs text-slate-500">{review.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}


