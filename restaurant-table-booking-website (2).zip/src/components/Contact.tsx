import React, { useState } from "react";
import { Mail, Phone, MapPin, Clock, MessageSquare, Send, CheckCircle2, ChevronDown, ChevronUp, ShieldCheck } from "lucide-react";

const INDIAN_FAQS = [
  {
    question: "Can I adjust the spice level of the dishes?",
    answer: "Yes, absolutely! While preparing our classic curries and tandoori tikka, you can request mild, medium, or traditional Indian spicy levels. Please inform your server or mention it in the booking notes."
  },
  {
    question: "Do you have pure vegetarian (Jain) options?",
    answer: "Yes! We specialize in vegetarian cuisines. We have separate tandoors and cooking utensils specifically dedicated to pure vegetarian and Jain preparations (no onion, garlic, or root vegetables) upon request."
  },
  {
    question: "How do I modify my table reservation?",
    answer: "You can modify or cancel your booking instantly online via our Admin Panel, or by calling our Guest Relationship Chobdar directly at +91 98765 43210 at least 2 hours before your scheduled arrival."
  },
  {
    question: "Is there a dress code for Shahi Rasoi?",
    answer: "We welcome all our guests in traditional Indian ethnic wear or smart casuals. We politely request guests to refrain from wearing sportswear, shorts, or flip-flops inside our fine-dining chambers."
  },
  {
    question: "Can we host large family banquets or kitty parties?",
    answer: "Yes! We host majestic Indian wedding receptions, family kitty parties, corporate events, and traditional sangeet celebrations. Contact our Banquets Desk at banquets@shahirasoi.com."
  }
];

export default function Contact() {
  // Form State
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState(false);

  // FAQ State
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const validate = () => {
    const tempErrors: Record<string, string> = {};
    if (!name.trim()) tempErrors.name = "Your Name is required.";
    if (!email.trim()) tempErrors.email = "Your Email is required.";
    else if (!/\S+@\S+\.\S+/.test(email)) tempErrors.email = "Please enter a valid email address.";
    if (!subject.trim()) tempErrors.subject = "Subject is required.";
    if (!message.trim()) tempErrors.message = "Message cannot be empty.";
    
    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSuccess(true);
    setName("");
    setEmail("");
    setSubject("");
    setMessage("");
    setErrors({});
    
    setTimeout(() => {
      setSuccess(false);
    }, 5000);
  };

  return (
    <div className="bg-[#041510] text-[#fbf8f3] min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            Connect With Our Team
          </h1>
          <p className="text-slate-400 mt-3 text-sm sm:text-base font-light">
            Have questions about our menus, private royal chambers, or reservation systems? Drop us a line, and our guest representatives will respond within 24 hours.
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 max-w-6xl mx-auto items-start">
          
          {/* LEFT: Contact Information (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#02110c] border border-[#d97706]/10 p-6 sm:p-8 rounded-2xl shadow-xl">
              <h3 className="text-xl font-bold text-white mb-6">Imperial Locations</h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-[#d97706]/10 border border-[#d97706]/20 text-[#f59e0b] p-3 rounded-xl">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">Shahi Court Delhi</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed font-light">
                      Block H, Connaught Place, New Delhi, Delhi 110001 <br />
                      Opposite Regal Cinema
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-[#d97706]/10 border border-[#d97706]/20 text-[#f59e0b] p-3 rounded-xl">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">Shahi Mahal Mumbai</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed font-light">
                      Marine Drive, Nariman Point, Mumbai, Maharashtra 400021 <br />
                      Near Oberoi Towers
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-[#d97706]/10 border border-[#d97706]/20 text-[#f59e0b] p-3 rounded-xl">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">Reservations & Concierge</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed font-mono">
                      Mobile: +91 98765 43210 <br />
                      Toll-Free: 1800 456 7890
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-[#d97706]/10 border border-[#d97706]/20 text-[#f59e0b] p-3 rounded-xl">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">General & Corporate Emails</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed font-light">
                      General Concierge: royal@shahirasoi.com <br />
                      Banquets Desk: banquets@shahirasoi.com
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-[#d97706]/10 border border-[#d97706]/20 text-[#f59e0b] p-3 rounded-xl">
                    <Clock className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">Operating Hours</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed font-light">
                      Monday - Sunday: 11:00 AM - 11:00 PM <br />
                      <span className="text-[#f59e0b] font-semibold">Tandoor & Buffet Closes:</span> 10:30 PM
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Support Guarantee Info Box */}
            <div className="bg-[#02110c] border border-[#d97706]/10 p-5 rounded-2xl flex items-center space-x-4">
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-2.5 rounded-xl">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div className="text-xs">
                <h4 className="font-bold text-white">Your Data is Secure</h4>
                <p className="text-slate-400 mt-0.5 leading-relaxed font-light">
                  We adhere to strict privacy laws. Your contact submissions are encrypted and processed securely. No spam.
                </p>
              </div>
            </div>
          </div>

          {/* RIGHT: Contact Form (7 Cols) */}
          <div className="lg:col-span-7 bg-[#02110c] border border-[#d97706]/10 p-6 sm:p-8 rounded-2xl shadow-xl">
            <h3 className="text-xl font-bold text-white mb-6">Send Us a Message</h3>
            
            {success && (
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 mb-6 flex items-center space-x-3 text-emerald-400">
                <CheckCircle2 className="h-5 w-5 flex-shrink-0 animate-bounce" />
                <div className="text-xs">
                  <p className="font-bold">Message Sent Successfully!</p>
                  <p className="text-slate-400 mt-0.5">Thank you for reaching out. Our customer experience team will contact you shortly.</p>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Your Name
                  </label>
                  <input
                    type="text"
                    placeholder="Arjun Sharma"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full bg-[#041510] border ${
                      errors.name ? "border-rose-500/80 focus:border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                    } rounded-xl py-2.5 px-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors`}
                  />
                  {errors.name && <span className="text-[11px] text-rose-400 mt-1 block">{errors.name}</span>}
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Your Email
                  </label>
                  <input
                    type="email"
                    placeholder="arjun@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`w-full bg-[#041510] border ${
                      errors.email ? "border-rose-500/80 focus:border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                    } rounded-xl py-2.5 px-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors`}
                  />
                  {errors.email && <span className="text-[11px] text-rose-400 mt-1 block">{errors.email}</span>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Subject
                </label>
                <input
                  type="text"
                  placeholder="Private Chambers / Kitty Parties / Catering"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className={`w-full bg-[#041510] border ${
                    errors.subject ? "border-rose-500/80 focus:border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                  } rounded-xl py-2.5 px-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors`}
                />
                {errors.subject && <span className="text-[11px] text-rose-400 mt-1 block">{errors.subject}</span>}
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Your Message
                </label>
                <textarea
                  rows={4}
                  placeholder="How can we assist you today? Let us know any special requirements..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className={`w-full bg-[#041510] border ${
                    errors.message ? "border-rose-500/80 focus:border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                  } rounded-xl py-2.5 px-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors resize-none`}
                />
                {errors.message && <span className="text-[11px] text-rose-400 mt-1 block">{errors.message}</span>}
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black py-3 rounded-xl transition-all flex items-center justify-center space-x-2 shadow-lg cursor-pointer"
              >
                <Send className="h-4 w-4" />
                <span>Send Message</span>
              </button>
            </form>
          </div>
        </div>

        {/* FAQS Accordion */}
        <div className="max-w-4xl mx-auto mt-20 bg-[#02110c] border border-[#d97706]/10 rounded-2xl overflow-hidden p-6 sm:p-8 shadow-xl">
          <div className="flex items-center space-x-3 mb-8 border-b border-[#07241b] pb-4">
            <MessageSquare className="text-[#f59e0b] h-6 w-6" />
            <h3 className="text-xl font-bold text-white">Frequently Asked Questions</h3>
          </div>

          <div className="space-y-4">
            {INDIAN_FAQS.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div 
                  key={index}
                  className="bg-[#041510] border border-[#d97706]/10 rounded-xl overflow-hidden transition-all duration-300"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full px-5 py-4 flex justify-between items-center text-left hover:bg-[#02110c] transition-colors cursor-pointer"
                  >
                    <span className="font-bold text-white text-sm sm:text-base">{faq.question}</span>
                    {isOpen ? <ChevronUp className="h-5 w-5 text-[#f59e0b]" /> : <ChevronDown className="h-5 w-5 text-slate-400" />}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-400 border-t border-[#02110c]/40 leading-relaxed font-light animate-fadeIn">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}
