import React from "react";
import { UtensilsCrossed, Calendar, Phone, Home, ShieldAlert, Terminal, Menu, X, BookOpen, LogIn, LogOut, UserCheck } from "lucide-react";

interface NavbarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  currentUser: { name: string; email: string; phone: string; role: 'customer' | 'admin' } | null;
  onLogout: () => void;
}

export default function Navbar({ currentPage, setCurrentPage, currentUser, onLogout }: NavbarProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  const navItems = [
    { id: "home", label: "Home Story", icon: Home },
    { id: "menu", label: "Shahi Menu", icon: BookOpen },
    { id: "booking", label: "Book a Table", icon: Calendar },
    { id: "contact", label: "Contact Us", icon: Phone },
    { id: "admin", label: "Admin Panel", icon: ShieldAlert },
    { id: "dev", label: "XAMPP Code Exporter", icon: Terminal },
  ];

  return (
    <nav className="bg-[#02110c] border-b border-[#d97706]/15 text-white sticky top-0 z-50 backdrop-blur-md bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div 
            onClick={() => setCurrentPage("home")} 
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] p-2.5 rounded-xl shadow-lg shadow-[#d97706]/20 transition-all">
              <UtensilsCrossed className="h-6 w-6" />
            </div>
            <div>
              <span className="text-2xl font-black tracking-wider text-white">
                SHAHI RASOI
              </span>
              <span className="text-[10px] block font-semibold text-[#f59e0b] tracking-widest uppercase">
                Imperial Indian Dining
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              // Only show Admin Panel and XAMPP Exporter to verified admin user logins
              if ((item.id === "admin" || item.id === "dev") && currentUser?.role !== "admin") {
                return null;
              }

              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentPage(item.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 cursor-pointer ${
                    isActive
                      ? "bg-[#d97706]/10 text-[#f59e0b] border-b-2 border-[#d97706] rounded-b-none"
                      : "text-slate-300 hover:text-white hover:bg-[#07241b]"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Dynamic Login / User Profile Indicator on Navbar */}
          <div className="hidden md:flex items-center space-x-4">
            {currentUser ? (
              <div className="flex items-center space-x-3 bg-[#041510] border border-[#d97706]/20 py-1.5 pl-3 pr-2.5 rounded-xl">
                <div className="bg-[#d97706] text-[#041510] p-1.5 rounded-lg flex items-center justify-center">
                  <UserCheck className="h-4 w-4" />
                </div>
                <div className="text-left">
                  <span className="text-xs font-black block text-white truncate max-w-[90px]">
                    {currentUser.name}
                  </span>
                  <span className="text-[8px] block uppercase font-bold text-[#f59e0b] tracking-wider">
                    {currentUser.role}
                  </span>
                </div>
                <button
                  onClick={onLogout}
                  title="Logout"
                  className="text-rose-400 hover:text-rose-300 p-1 rounded hover:bg-rose-500/10 cursor-pointer transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setCurrentPage("auth")}
                className="bg-[#07241b] border border-[#d97706]/20 hover:bg-[#d97706]/10 text-[#f59e0b] font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
              >
                <LogIn className="h-3.5 w-3.5" />
                <span>Sign In</span>
              </button>
            )}

            <button
              onClick={() => setCurrentPage("booking")}
              className="bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black px-5 py-2.5 rounded-xl shadow-lg shadow-[#d97706]/20 hover:brightness-110 active:scale-95 transition-all flex items-center space-x-2 text-sm cursor-pointer"
            >
              <Calendar className="h-4 w-4" />
              <span>Book Table</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center space-x-2">
            {currentUser && (
              <span className="text-[10px] bg-[#d97706]/20 text-[#f59e0b] font-black uppercase px-2 py-1 rounded border border-[#d97706]/30">
                {currentUser.name.split(" ")[0]}
              </span>
            )}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-400 hover:text-white hover:bg-[#07241b] p-2 rounded-lg transition-colors cursor-pointer"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-[#041510] border-b border-[#d97706]/15 animate-fadeIn">
          <div className="px-2 pt-2 pb-4 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              if ((item.id === "admin" || item.id === "dev") && currentUser?.role !== "admin") {
                return null;
              }

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setIsOpen(false);
                  }}
                  className={`flex items-center space-x-3 w-full px-4 py-3 rounded-xl text-left text-base font-semibold transition-all cursor-pointer ${
                    isActive
                      ? "bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510]"
                      : "text-slate-300 hover:text-white hover:bg-[#07241b]"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}

            {/* Mobile login action */}
            <div className="pt-2 px-4 space-y-2">
              {currentUser ? (
                <button
                  onClick={() => {
                    onLogout();
                    setIsOpen(false);
                  }}
                  className="w-full bg-rose-500/10 border border-rose-500/30 text-rose-400 font-bold py-3 rounded-xl transition-all text-center flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Logout ({currentUser.name})</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setCurrentPage("auth");
                    setIsOpen(false);
                  }}
                  className="w-full bg-[#07241b] border border-[#d97706]/20 text-[#f59e0b] font-bold py-3 rounded-xl transition-all text-center flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <LogIn className="h-4 w-4" />
                  <span>Sign In</span>
                </button>
              )}

              <button
                onClick={() => {
                  setCurrentPage("booking");
                  setIsOpen(false);
                }}
                className="w-full bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black py-3 rounded-xl shadow-lg transition-all text-center flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Calendar className="h-5 w-5" />
                <span>Book a Table Now</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
