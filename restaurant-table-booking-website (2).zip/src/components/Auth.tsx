import React, { useState } from "react";
import { Lock, Mail, Phone, User, ShieldCheck, Key, LogIn, CheckCircle2, Star, Sparkles } from "lucide-react";

interface AuthProps {
  onLoginSuccess: (user: { name: string; email: string; phone: string; role: 'customer' | 'admin' }) => void;
  setCurrentPage: (page: string) => void;
  redirectTo?: string | null;
}

export default function Auth({ onLoginSuccess, setCurrentPage, redirectTo }: AuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [isAdminMode, setIsAdminMode] = useState(false);

  // Form Fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Validation / Loading States
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [successMsg, setSuccessMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const validateForm = () => {
    const tempErrors: Record<string, string> = {};

    if (!isLogin) {
      if (!name.trim()) tempErrors.name = "Full Name is required.";
      
      if (!phone.trim()) tempErrors.phone = "Phone number is required.";
      else {
        const cleanPhone = phone.replace(/[\s-]/g, "");
        const isIndianPhone = /^(?:\+91|91)?[6789]\d{9}$/.test(cleanPhone);
        if (!isIndianPhone) {
          tempErrors.phone = "Please enter a valid 10-digit Indian phone number (with optional +91).";
        }
      }
    }

    if (!email.trim()) tempErrors.email = "Email address is required.";
    else if (!/\S+@\S+\.\S+/.test(email)) tempErrors.email = "Please enter a valid email address.";

    if (!password) tempErrors.password = "Password is required.";
    else if (password.length < 6) tempErrors.password = "Password must be at least 6 characters long.";

    if (!isLogin && password !== confirmPassword) {
      tempErrors.confirmPassword = "Passwords do not match.";
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    setErrors({});
    
    // Simulate API network latency (400ms)
    setTimeout(() => {
      setIsLoading(false);
      
      if (isLogin) {
        // Authenticating User Login (Mock demo checking credentials)
        if (isAdminMode) {
          if (email === "abhayrana4409@gmail.com" && password === "admin123") {
            onLoginSuccess({
              name: "Abhay",
              email: email,
              phone: "+91 98765 43210",
              role: "admin",
            });
            setSuccessMsg("Welcome Abhay! Accessing secure administrator dashboards...");
            setTimeout(() => {
              setCurrentPage("admin");
            }, 1000);
          } else {
            setErrors({
              email: "Invalid admin credentials. Use abhayrana4409@gmail.com / admin123 for sandbox testing.",
            });
          }
        } else {
          // Normal customer login - App.tsx handles redirect to booking
          onLoginSuccess({
            name: name || "Noble Guest",
            email: email,
            phone: phone || "+91 98765 43210",
            role: "customer",
          });
          setSuccessMsg(redirectTo ? "Login successful! Redirecting to booking..." : "Welcome back to Shahi Rasoi!");
        }
      } else {
        // Registration Success State
        setSuccessMsg("Accolades! Your royal account has been registered.");
        setTimeout(() => {
          setIsLogin(true);
          setSuccessMsg("");
        }, 1200);
      }
    }, 400);
  };

  return (
    <div className="bg-[#041510] text-[#fbf8f3] min-h-[80vh] py-12 px-4 sm:px-6 lg:px-8 flex flex-col items-center justify-center">
      {/* Redirect Banner - shows when user came from booking page */}
      {redirectTo && (
        <div className="max-w-4xl w-full mb-6 bg-[#f59e0b]/10 border border-[#f59e0b]/30 rounded-xl p-4 flex items-center gap-3">
          <div className="bg-[#f59e0b] p-2 rounded-lg">
            <Lock className="h-5 w-5 text-[#041510]" />
          </div>
          <div>
            <p className="text-[#f59e0b] font-bold text-sm">Login Required to Book Table</p>
            <p className="text-slate-400 text-xs">Sign in or create an account to continue with your table reservation.</p>
          </div>
        </div>
      )}

      <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-12 bg-[#02110c] border border-[#d97706]/15 rounded-3xl overflow-hidden shadow-2xl">
        
        {/* LEFT COMPONENT: Welcome Text (5 cols) */}
        <div className="md:col-span-5 bg-gradient-to-br from-[#07241b] to-[#041510] p-8 flex flex-col justify-between border-r border-[#d97706]/10 relative overflow-hidden">
          {/* Traditional pattern background simulation */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl" />
          
          <div className="space-y-6 z-10">
            <div className="inline-flex items-center space-x-2 bg-[#d97706]/15 border border-[#d97706]/30 px-3 py-1 rounded-full text-[10px] font-bold text-[#f59e0b] uppercase tracking-widest">
              <Sparkles className="h-3 w-3" />
              <span>Imperial Banquet Pass</span>
            </div>
            
            <h2 className="text-2xl sm:text-3xl font-black text-white leading-tight">
              A Realm of <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d97706] to-[#f59e0b]">
                Traditional Gastronomy
              </span>
            </h2>
            
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-light">
              Creating an account allows you to securely manage your table reservations, view personalized chefs tables, and modify seating charts.
            </p>
          </div>

          <div className="space-y-4 z-10 pt-8 border-t border-[#041510]/80">
            <div className="flex items-center space-x-3 text-xs">
              <Star className="h-4 w-4 text-[#f59e0b] fill-current" />
              <span className="text-slate-300 font-medium">Accumulate loyalty points on dine-in</span>
            </div>
            <div className="flex items-center space-x-3 text-xs">
              <ShieldCheck className="h-4 w-4 text-[#f59e0b]" />
              <span className="text-slate-300 font-medium">Safe SQL sanitization protocols active</span>
            </div>
          </div>
        </div>

        {/* RIGHT COMPONENT: Input Fields (7 cols) */}
        <div className="md:col-span-7 p-8 sm:p-10 flex flex-col justify-center">
          
          {/* Auth Tab selectors */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex space-x-4">
              <button
                onClick={() => {
                  setIsLogin(true);
                  setErrors({});
                }}
                className={`text-lg font-black transition-all pb-1.5 border-b-2 cursor-pointer ${
                  isLogin ? "text-white border-[#d97706]" : "text-slate-500 border-transparent hover:text-slate-300"
                }`}
              >
                Sign In
              </button>
              <button
                onClick={() => {
                  setIsLogin(false);
                  setIsAdminMode(false);
                  setErrors({});
                }}
                className={`text-lg font-black transition-all pb-1.5 border-b-2 cursor-pointer ${
                  !isLogin ? "text-white border-[#d97706]" : "text-slate-500 border-transparent hover:text-slate-300"
                }`}
              >
                Create Account
              </button>
            </div>

            {/* Admin toggle checkbox */}
            {isLogin && (
              <button
                onClick={() => {
                  setIsAdminMode(!isAdminMode);
                  setErrors({});
                }}
                className={`text-[10px] uppercase tracking-widest font-black px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer ${
                  isAdminMode 
                    ? "bg-[#d97706] text-[#041510] border-transparent" 
                    : "bg-[#041510] text-slate-400 border-[#d97706]/10 hover:text-slate-300"
                }`}
              >
                Admin Mode
              </button>
            )}
          </div>

          {/* Alert Success */}
          {successMsg && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs p-4 rounded-xl mb-6 flex items-center space-x-2">
              <CheckCircle2 className="h-4 w-4 flex-shrink-0 animate-bounce" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* NAME FIELD (Signup only) */}
            {!isLogin && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Pranav Patel"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full bg-[#041510] border ${
                      errors.name ? "border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                    } rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-all`}
                  />
                </div>
                {errors.name && <span className="text-[11px] text-rose-400 mt-1 block">{errors.name}</span>}
              </div>
            )}

            {/* PHONE FIELD (Signup only) */}
            {!isLogin && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Indian Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className={`w-full bg-[#041510] border ${
                      errors.phone ? "border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                    } rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-all`}
                  />
                </div>
                {errors.phone && <span className="text-[11px] text-rose-400 mt-1 block">{errors.phone}</span>}
              </div>
            )}

            {/* EMAIL FIELD */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                {isAdminMode ? "Admin Email Address" : "Email Address"}
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                <input
                  type="email"
                  placeholder={isAdminMode ? "abhayrana4409@gmail.com" : "customer@example.com"}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full bg-[#041510] border ${
                    errors.email ? "border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                  } rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-all`}
                />
              </div>
              {errors.email && <span className="text-[11px] text-rose-400 mt-1 block">{errors.email}</span>}
            </div>

            {/* PASSWORD FIELD */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                <input
                  type="password"
                  placeholder="••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full bg-[#041510] border ${
                    errors.password ? "border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                  } rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-all`}
                />
              </div>
              {errors.password && <span className="text-[11px] text-rose-400 mt-1 block">{errors.password}</span>}
            </div>

            {/* CONFIRM PASSWORD (Signup only) */}
            {!isLogin && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Confirm Password
                </label>
                <div className="relative">
                  <Key className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type="password"
                    placeholder="••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={`w-full bg-[#041510] border ${
                      errors.confirmPassword ? "border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                    } rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-all`}
                  />
                </div>
                {errors.confirmPassword && <span className="text-[11px] text-rose-400 mt-1 block">{errors.confirmPassword}</span>}
              </div>
            )}

            {/* Default sandbox login tips */}
            {isLogin && (
              <div className="bg-[#041510] p-3 rounded-xl border border-[#d97706]/10 text-[10px] text-slate-400 font-light leading-normal">
                {isAdminMode ? (
                  <span><strong>Sandbox Hint:</strong> Enter email <code className="text-amber-400">abhayrana4409@gmail.com</code> with password <code className="text-amber-400">admin123</code> to test high-level admin controls.</span>
                ) : (
                  <span><strong>Sandbox Hint:</strong> Enter any valid email and password to instantly register or log in as a premium customer.</span>
                )}
              </div>
            )}

            {/* SUBMIT BUTTON */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black py-3.5 rounded-xl transition-all shadow-lg hover:brightness-110 flex items-center justify-center space-x-2 text-sm cursor-pointer disabled:opacity-50"
            >
              <LogIn className="h-4.5 w-4.5" />
              <span>{isLogin ? "Enter Royal Vault" : "Create My Feast Pass"}</span>
            </button>
          </form>

        </div>

      </div>
    </div>
  );
}
