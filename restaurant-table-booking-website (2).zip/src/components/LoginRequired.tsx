import { Lock, LogIn, ShieldCheck, ChevronRight } from "lucide-react";

interface LoginRequiredProps {
  setCurrentPage: (page: string) => void;
}

export default function LoginRequired({ setCurrentPage }: LoginRequiredProps) {
  return (
    <div className="bg-[#041510] text-[#fbf8f3] min-h-[70vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full text-center">
        {/* Lock Icon Animation */}
        <div className="relative inline-block mb-8">
          <div className="bg-[#d97706]/10 border border-[#d97706]/30 p-6 rounded-full animate-pulse">
            <Lock className="h-16 w-16 text-[#f59e0b]" />
          </div>
          <div className="absolute -top-2 -right-2 bg-[#f59e0b] text-[#041510] p-1.5 rounded-full">
            <ShieldCheck className="h-5 w-5" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-4xl font-black text-white mb-3">
          Login Required
        </h1>
        <p className="text-slate-400 text-sm sm:text-base mb-8 leading-relaxed">
          Welcome to <span className="text-[#f59e0b] font-bold">Shahi Rasoi</span>! 
          You need to sign in or create an account before reserving your royal dining table.
        </p>

        {/* Why Login Card */}
        <div className="bg-[#02110c] border border-[#d97706]/10 rounded-2xl p-6 mb-8 text-left">
          <h3 className="font-bold text-white text-sm mb-4 flex items-center gap-2">
            <span className="text-[#f59e0b]">👑</span> Why Login to Book?
          </h3>
          <ul className="space-y-3 text-xs text-slate-400">
            <li className="flex items-start gap-2">
              <ChevronRight className="h-4 w-4 text-[#f59e0b] flex-shrink-0 mt-0.5" />
              <span>Track your reservation history and upcoming dining plans</span>
            </li>
            <li className="flex items-start gap-2">
              <ChevronRight className="h-4 w-4 text-[#f59e0b] flex-shrink-0 mt-0.5" />
              <span>Get exclusive early access to special festival menus and events</span>
            </li>
            <li className="flex items-start gap-2">
              <ChevronRight className="h-4 w-4 text-[#f59e0b] flex-shrink-0 mt-0.5" />
              <span>Receive instant confirmation emails for all bookings</span>
            </li>
            <li className="flex items-start gap-2">
              <ChevronRight className="h-4 w-4 text-[#f59e0b] flex-shrink-0 mt-0.5" />
              <span>Earn loyalty points with every visit to unlock premium benefits</span>
            </li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={() => setCurrentPage("auth")}
            className="w-full bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black py-4 rounded-xl shadow-lg shadow-[#d97706]/20 hover:brightness-110 transition-all flex items-center justify-center gap-3 text-sm cursor-pointer"
          >
            <LogIn className="h-5 w-5" />
            <span>Sign In to Continue Booking</span>
          </button>

          <button
            onClick={() => setCurrentPage("home")}
            className="w-full bg-[#07241b] border border-[#d97706]/15 text-slate-300 font-bold py-3 rounded-xl hover:bg-[#0c3528] transition-all text-sm cursor-pointer"
          >
            Back to Home
          </button>
        </div>

        {/* Security Note */}
        <p className="text-[10px] text-slate-500 mt-6 flex items-center justify-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5" />
          <span>Your data is protected with enterprise-grade encryption</span>
        </p>
      </div>
    </div>
  );
}
