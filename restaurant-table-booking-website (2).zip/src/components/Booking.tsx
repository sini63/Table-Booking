import React, { useState } from "react";
import { Calendar, User, Mail, Phone, Users, Clock, MapPin, CheckCircle, Ticket, Code2, AlertTriangle } from "lucide-react";
import { Booking } from "../types";

interface BookingProps {
  onAddBooking: (booking: Omit<Booking, "id" | "createdAt" | "tableNumber">) => Booking;
  setExecutedQueries: React.Dispatch<React.SetStateAction<string[]>>;
  currentUser: { name: string; email: string; phone: string; role: 'customer' | 'admin' };
}

const INDIAN_TABLE_AREAS = [
  { id: "Royal Durbar", label: "Shahi Durbar Hall", icon: "🏛️", description: "Grand interior dining under crystal chandeliers with classical live sitar music.", tables: [1, 2, 3, 4] },
  { id: "Haveli Courtyard", label: "Haveli Courtyard", icon: "⛲", description: "Open-air dining under fairylights around traditional marble water fountain.", tables: [5, 6, 7, 8] },
  { id: "Maharajah Booth", label: "Maharajah Booths", icon: "👑", description: "Private intimate seating with plush silk cushions and royal drapes.", tables: [9, 10, 11, 12, 13, 14] },
  { id: "Saffron Terrace", label: "Saffron Terrace", icon: "🌅", description: "Overlooking manicured rose gardens with romantic candle lamps.", tables: [15, 16, 17, 18] },
];

export default function BookingForm({ onAddBooking, setExecutedQueries, currentUser }: BookingProps) {
  // Form State - Pre-fill with logged-in user's data
  const [name, setName] = useState(currentUser?.name || "");
  const [email, setEmail] = useState(currentUser?.email || "");
  const [phone, setPhone] = useState(currentUser?.phone || "");
  const [people, setPeople] = useState(2);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [tableLocation, setTableLocation] = useState("Maharajah Booth");
  const [selectedTable, setSelectedTable] = useState<number>(9);

  // Validation / Message State
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showSuccess, setShowSuccess] = useState(false);
  const [bookingTicket, setBookingTicket] = useState<Booking | null>(null);
  const [sqlLog, setSqlLog] = useState<string>("");

  // Get today's date in YYYY-MM-DD format for past-date disabling
  const todayStr = new Date().toISOString().split("T")[0];

  // Table area select handler
  const handleAreaChange = (area: string) => {
    setTableLocation(area);
    const areaTables = INDIAN_TABLE_AREAS.find((a) => a.id === area)?.tables || [];
    setSelectedTable(areaTables[0] || 1);
  };

  // Form Validation (Including Indian Phone format validation)
  const validateForm = () => {
    const tempErrors: Record<string, string> = {};

    if (!name.trim()) tempErrors.name = "Full Name is required.";
    else if (name.length < 3) tempErrors.name = "Name must be at least 3 characters.";

    if (!email.trim()) tempErrors.email = "Email is required.";
    else if (!/\S+@\S+\.\S+/.test(email)) tempErrors.email = "Please enter a valid email address.";

    if (!phone.trim()) tempErrors.phone = "Phone number is required.";
    else {
      // Validating Indian phone number formats (e.g. +91 9876543210, 919876543210, or 10-digit mobile 9876543210)
      const cleanPhone = phone.replace(/[\s-]/g, "");
      const isIndianPhone = /^(?:\+91|91)?[6789]\d{9}$/.test(cleanPhone);
      if (!isIndianPhone) {
        tempErrors.phone = "Please enter a valid 10-digit Indian phone number (with optional +91).";
      }
    }

    if (!date) tempErrors.date = "Please select a booking date.";
    else if (date < todayStr) tempErrors.date = "You cannot reserve a table for a past date.";

    if (!time) tempErrors.time = "Please select a dining time.";
    else {
      const hour = parseInt(time.split(":")[0]);
      if (hour < 11 || hour > 22) {
        tempErrors.time = "Our operating hours are between 11:00 AM and 11:00 PM (Last seating 10:00 PM).";
      }
    }

    if (people < 1 || people > 10) {
      tempErrors.people = "Reservations are limited to between 1 and 10 guests online.";
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  // Handle Form Submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    // Create Booking
    const newBooking = onAddBooking({
      name,
      email,
      phone,
      people,
      date,
      time,
      tableLocation,
    });

    // Add Simulated SQL Logs using database 'restaurant_india'
    const insertSQL = `PREPARE stmt FROM 'INSERT INTO bookings (name, email, phone, people, date, time, table_location, table_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
SET @name = '${name.replace(/'/g, "''")}', @email = '${email}', @phone = '${phone}', @people = ${people}, @date = '${date}', @time = '${time}', @table_location = '${tableLocation}', @table_number = ${selectedTable};
EXECUTE stmt USING @name, @email, @phone, @people, @date, @time, @table_location, @table_number;
DEALLOCATE PREPARE stmt;`;

    setSqlLog(insertSQL);
    setExecutedQueries((prev) => [insertSQL, ...prev]);

    // Store completed booking for receipt
    setBookingTicket({
      ...newBooking,
      tableNumber: selectedTable,
    });
    
    setShowSuccess(true);
  };

  const handleReset = () => {
    setName("");
    setEmail("");
    setPhone("");
    setPeople(2);
    setDate("");
    setTime("");
    setTableLocation("Maharajah Booth");
    setSelectedTable(9);
    setErrors({});
    setShowSuccess(false);
    setBookingTicket(null);
  };

  return (
    <div className="bg-[#041510] text-[#fbf8f3] min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          {/* Welcome User Badge */}
          <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-4 py-2 rounded-full text-xs font-bold mb-4">
            <CheckCircle className="h-4 w-4" />
            <span>Booking as: {currentUser?.name} ({currentUser?.email})</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            Reserve Your Imperial Feast
          </h1>
          <p className="text-slate-400 mt-3 text-sm sm:text-base font-light">
            Welcome, <span className="text-[#f59e0b] font-semibold">{currentUser?.name?.split(' ')[0]}</span>! 
            Select your preferred royal dining zone, date, arrival time, and guest count.
          </p>
        </div>

        {/* SQL Prepared Statement Alert */}
        <div className="bg-[#d97706]/10 border border-[#d97706]/35 rounded-2xl p-4 mb-8 flex flex-col md:flex-row items-center justify-between gap-4 max-w-5xl mx-auto">
          <div className="flex items-start space-x-3">
            <div className="bg-[#d97706] text-[#041510] p-2 rounded-xl mt-0.5 shadow-md">
              <Code2 className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Interactive SQL Prepared Statement Suite Active</h4>
              <p className="text-xs text-slate-400 mt-1 max-w-2xl font-light">
                Every reservation made writes safely to our emulated <code className="text-amber-400 font-mono">restaurant_india</code> database. We use secure PDO parameters to block SQL injection attacks completely.
              </p>
            </div>
          </div>
          <span className="text-[10px] font-black uppercase tracking-wider bg-[#d97706]/20 text-[#f59e0b] px-2.5 py-1 rounded border border-[#d97706]/30">
            Database: restaurant_india
          </span>
        </div>

        {!showSuccess ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-6xl mx-auto">
            {/* LEFT: Booking Form (7 Cols) */}
            <div className="lg:col-span-7 bg-[#02110c] border border-[#d97706]/10 p-6 sm:p-8 rounded-2xl shadow-xl flex flex-col justify-between">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="border-b border-[#07241b] pb-4 mb-4">
                  <h3 className="text-lg font-bold text-white">Shahi Reservation Form</h3>
                  <p className="text-xs text-slate-400 font-light">Provide contact details below to secure your complimentary reservation.</p>
                </div>

                {/* Form Row 1: Name & Email (Auto-filled from account, read-only) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Guest Name <span className="text-emerald-500">(from account)</span>
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                      <input
                        type="text"
                        value={name}
                        readOnly
                        className="w-full bg-[#07241b] border border-[#d97706]/10 rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-300 cursor-not-allowed"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Email Address <span className="text-emerald-500">(from account)</span>
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                      <input
                        type="email"
                        value={email}
                        readOnly
                        className="w-full bg-[#07241b] border border-[#d97706]/10 rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-300 cursor-not-allowed"
                      />
                    </div>
                  </div>
                </div>

                {/* Form Row 2: Phone & Guests */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Indian Phone Number <span className="text-emerald-500">(from account)</span>
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                      <input
                        type="tel"
                        value={phone}
                        readOnly
                        className="w-full bg-[#07241b] border border-[#d97706]/10 rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-300 cursor-not-allowed"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                      People Count (Max 10)
                    </label>
                    <div className="relative">
                      <Users className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                      <input
                        type="number"
                        min="1"
                        max="10"
                        value={people}
                        onChange={(e) => setPeople(parseInt(e.target.value) || 0)}
                        className={`w-full bg-[#041510] border ${
                          errors.people ? "border-rose-500/80 focus:border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                        } rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors`}
                      />
                    </div>
                    {errors.people && <span className="text-[11px] text-rose-400 mt-1 block">{errors.people}</span>}
                  </div>
                </div>

                {/* Form Row 3: Date & Time */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Arrival Date
                    </label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                      <input
                        type="date"
                        min={todayStr}
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className={`w-full bg-[#041510] border ${
                          errors.date ? "border-rose-500/80 focus:border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                        } rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors`}
                      />
                    </div>
                    {errors.date && <span className="text-[11px] text-rose-400 mt-1 block">{errors.date}</span>}
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex justify-between">
                      <span>Arrival Time</span>
                      <span className="text-[9px] text-slate-500 font-semibold normal-case">11:00 AM - 11:00 PM</span>
                    </label>
                    <div className="relative">
                      <Clock className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                      <input
                        type="time"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        className={`w-full bg-[#041510] border ${
                          errors.time ? "border-rose-500/80 focus:border-rose-500" : "border-[#d97706]/10 focus:border-[#d97706]"
                        } rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors`}
                      />
                    </div>
                    {errors.time && <span className="text-[11px] text-rose-400 mt-1 block">{errors.time}</span>}
                  </div>
                </div>

                {/* Table Location Display */}
                <div className="p-4 bg-[#041510] rounded-xl border border-[#d97706]/15">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">Selected Royal Chamber</span>
                      <span className="text-lg font-black text-[#f59e0b] mt-0.5 block">{tableLocation}</span>
                    </div>
                    <div className="bg-[#d97706]/10 border border-[#d97706]/30 px-3 py-1.5 rounded-lg text-xs font-bold text-[#f59e0b]">
                      Table #{selectedTable} Selected
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black py-4 rounded-xl shadow-xl hover:brightness-110 active:scale-[0.99] transition-all flex items-center justify-center space-x-2"
                >
                  <Calendar className="h-5 w-5" />
                  <span>Reserve Saffron Table Now</span>
                </button>
              </form>
            </div>

            {/* RIGHT: Visual Seating Map (5 Cols) */}
            <div className="lg:col-span-5 bg-[#02110c] border border-[#d97706]/10 p-6 rounded-2xl shadow-xl flex flex-col justify-between">
              <div>
                <div className="border-b border-[#07241b] pb-4 mb-4">
                  <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                    <span>Courtyard Seating Selector</span>
                  </h3>
                  <p className="text-xs text-slate-400 font-light">Select from our premium chambers, durbars, and lush terrace seats.</p>
                </div>

                {/* Table Area Cards */}
                <div className="space-y-3">
                  {INDIAN_TABLE_AREAS.map((area) => {
                    const isSelected = tableLocation === area.id;
                    return (
                      <div
                        key={area.id}
                        onClick={() => handleAreaChange(area.id)}
                        className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? "bg-[#d97706]/10 border-[#d97706]"
                            : "bg-[#041510] border-[#d97706]/5 hover:bg-[#07241b] hover:border-[#d97706]/20"
                        }`}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <div className="flex items-center space-x-2">
                            <span className="text-xl">{area.icon}</span>
                            <h4 className="font-bold text-white text-sm">{area.label}</h4>
                          </div>
                          {isSelected && (
                            <span className="text-[10px] font-black uppercase tracking-wider text-[#f59e0b] bg-[#d97706]/15 border border-[#d97706]/30 px-2 py-0.5 rounded">
                              Active
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 font-light leading-normal">{area.description}</p>

                        {/* Interactive Seating Dots for this Area */}
                        <div className="flex flex-wrap gap-2 mt-3">
                          {area.tables.map((tblNum) => {
                            const isTblSelected = selectedTable === tblNum;
                            return (
                              <button
                                key={tblNum}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setTableLocation(area.id);
                                  setSelectedTable(tblNum);
                                }}
                                className={`h-8 w-8 rounded-lg text-xs font-extrabold flex items-center justify-center transition-all ${
                                  isTblSelected
                                    ? "bg-[#d97706] text-[#041510] scale-115 shadow-lg ring-2 ring-[#f59e0b]/50"
                                    : "bg-[#02110c] text-slate-300 border border-[#d97706]/10 hover:border-[#d97706]/30"
                                }`}
                              >
                                {tblNum}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Operating Guidelines Alert */}
              <div className="mt-6 p-4 bg-[#041510] rounded-xl border border-[#d97706]/10 flex items-center space-x-3">
                <MapPin className="text-[#f59e0b] h-5 w-5 flex-shrink-0" />
                <div className="text-xs">
                  <p className="font-bold text-white">Shahi Etiquette & Guidelines</p>
                  <p className="text-slate-400 mt-0.5 font-light">Traditional Smart Casual or Ethnic attire encouraged.</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* SUCCESS STATE / PRINTABLE CONFIRMATION TICKET */
          <div className="max-w-xl mx-auto bg-[#02110c] border border-[#d97706]/20 rounded-3xl overflow-hidden shadow-2xl animate-scaleIn">
            <div className="bg-gradient-to-r from-[#d97706] to-[#f59e0b] p-8 text-center text-[#041510] relative">
              <div className="absolute top-4 right-4 bg-[#041510] text-white rounded-full p-1.5">
                <CheckCircle className="h-6 w-6 text-[#f59e0b]" />
              </div>
              <h3 className="text-2xl font-black uppercase tracking-wider">Shahi Reservation Confirmed</h3>
              <p className="text-xs font-bold opacity-80 mt-1">Shahi Rasoi - Dining Receipt & Ticket</p>
            </div>

            <div className="p-6 space-y-6">
              {/* Reference Details */}
              <div className="grid grid-cols-2 gap-4 border-b border-[#07241b] pb-4">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Ticket ID</span>
                  <span className="font-mono text-sm font-bold text-[#f59e0b]">#SH-{(bookingTicket?.id || 0) + 100}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Date Issued</span>
                  <span className="text-xs text-white font-medium">{bookingTicket?.createdAt}</span>
                </div>
              </div>

              {/* Ticket details */}
              <div className="space-y-4 border-b border-[#07241b] pb-6">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-medium">Guest Name:</span>
                  <span className="text-sm font-bold text-white">{bookingTicket?.name}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-medium">Email Address:</span>
                  <span className="text-sm text-slate-300 font-medium">{bookingTicket?.email}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-medium">Phone Number:</span>
                  <span className="text-sm text-slate-300 font-medium font-mono">{bookingTicket?.phone}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-medium">Guest Size:</span>
                  <span className="text-sm font-bold text-[#f59e0b]">{bookingTicket?.people} Guests</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-medium">Dining Date:</span>
                  <span className="text-sm font-bold text-white">{bookingTicket?.date}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-medium">Arrival Time:</span>
                  <span className="text-sm font-bold text-white">{bookingTicket?.time}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-medium">Royal Area & Table:</span>
                  <span className="text-sm font-bold text-[#f59e0b]">{bookingTicket?.tableLocation} (Table #{bookingTicket?.tableNumber})</span>
                </div>
              </div>

              {/* Instructions */}
              <div className="p-4 bg-[#041510] border border-[#d97706]/10 rounded-xl text-center">
                <p className="text-xs text-slate-300 leading-relaxed font-light">
                  A verification confirmation has been sent to <strong className="text-white font-medium">{bookingTicket?.email}</strong>. Present this ticket to the Royal Chobdar on arrival.
                </p>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={handleReset}
                  className="flex-1 bg-[#07241b] hover:bg-[#0c3528] text-white font-bold py-3.5 rounded-xl transition-all text-xs sm:text-sm text-center border border-[#d97706]/10 cursor-pointer"
                >
                  Book Another Table
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex-1 bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black py-3.5 rounded-xl transition-all text-xs sm:text-sm text-center flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Ticket className="h-4 w-4" />
                  <span>Download / Print Receipt</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* EXECUTED SQL PREPARED STATEMENT PREVIEWER */}
        {sqlLog && (
          <div className="max-w-5xl mx-auto mt-12 bg-[#02110c] border border-[#d97706]/10 rounded-2xl overflow-hidden animate-fadeIn shadow-lg">
            <div className="bg-[#041510] px-5 py-4 border-b border-[#07241b] flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="bg-emerald-500/10 text-emerald-400 p-1.5 rounded-lg border border-emerald-500/20">
                  <Code2 className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-xs sm:text-sm">PHP & MySQL Backend Engine Live-Simulator</h4>
                  <p className="text-[10px] text-slate-400">PDO Prepared Statement generated for this action</p>
                </div>
              </div>
              <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                SQL INJECTION SECURE
              </span>
            </div>
            <div className="p-4 bg-[#041510]/80 font-mono text-[11px] sm:text-xs text-amber-300 overflow-x-auto whitespace-pre leading-relaxed border-b border-[#02110c]">
              {sqlLog}
            </div>
            <div className="p-3 bg-[#02110c]/40 text-[10px] text-slate-400 flex items-center space-x-2">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-500 flex-shrink-0" />
              <span>Prepared statements compile SQL commands separately from parameter inputs. This prevents hacker scripts inside parameters from executing as code!</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
