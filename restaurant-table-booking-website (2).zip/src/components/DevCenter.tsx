import { useState } from "react";
import { Terminal, Database, BookOpen, Copy, Check, Info, FileCode, Play, AlertCircle, RefreshCw } from "lucide-react";
import { Booking, CodeFile } from "../types";

interface DevCenterProps {
  bookings: Booking[];
  executedQueries: string[];
}

const DATABASE_SQL = `-- -------------------------------------------------------------
-- SQL Database Dump & Schema for 'restaurant_india'
-- -------------------------------------------------------------
-- Step 1: Create Database
CREATE DATABASE IF NOT EXISTS \`restaurant_india\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE \`restaurant_india\`;

-- Step 2: Create Table 'users' (Supports Login & Sign Up)
CREATE TABLE IF NOT EXISTS \`users\` (
  \`id\` INT(11) NOT NULL AUTO_INCREMENT,
  \`name\` VARCHAR(100) NOT NULL,
  \`email\` VARCHAR(100) NOT NULL UNIQUE,
  \`phone\` VARCHAR(20) NOT NULL,
  \`password\` VARCHAR(255) NOT NULL, -- Stores secure bcrypt-hashed passwords
  \`role\` VARCHAR(20) DEFAULT 'customer', -- 'customer' or 'admin'
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Step 3: Create Table 'bookings' (Linked to customers/users)
CREATE TABLE IF NOT EXISTS \`bookings\` (
  \`id\` INT(11) NOT NULL AUTO_INCREMENT,
  \`name\` VARCHAR(100) NOT NULL,
  \`phone\` VARCHAR(20) NOT NULL,
  \`email\` VARCHAR(100) NOT NULL,
  \`people\` INT(2) NOT NULL,
  \`date\` DATE NOT NULL,
  \`time\` TIME NOT NULL,
  \`table_location\` VARCHAR(100) DEFAULT 'Maharajah Booth',
  \`table_number\` INT(3) DEFAULT 9,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Step 4: Insert initial seed data for testing
-- Default Admin credentials: abhayrana4409@gmail.com / admin123
INSERT INTO \`users\` (\`name\`, \`email\`, \`phone\`, \`password\`, \`role\`) VALUES
('Abhay', 'abhayrana4409@gmail.com', '+919876543210', '$2y$10$f3b49S/I1KkZ33IAtD.bS.fP0O5v8pU1q7H5t9MvP.Zz9OqP7CgS.', 'admin'), -- bcrypt hash of 'admin123'
('Arjun Sharma', 'arjun@example.com', '+919876543210', '$2y$10$vWfPqf9bU5K6S8vS4DkXeOlO8P7Q7H8mN8vU7vMvP.Zz9OqP7CgS.', 'customer'); -- bcrypt hash of 'customer123'

INSERT INTO \`bookings\` (\`name\`, \`phone\`, \`email\`, \`people\`, \`date\`, \`time\`, \`table_location\`, \`table_number\`) VALUES
('Arjun Sharma', '+919876543210', 'arjun@example.com', 4, '2026-06-15', '19:30:00', 'Maharajah Booth', 9),
('Priya Nair', '+919812345678', 'priya.nair@example.com', 2, '2026-06-16', '20:30:00', 'Haveli Courtyard', 5);`;

const DB_CONNECT_PHP = `<?php
/**
 * db_connect.php
 * Secure Database Connection using PHP Data Objects (PDO)
 * Specially designed for database: restaurant_india
 */

$host = 'localhost';
$dbname = 'restaurant_india';
$username = 'root';
$password = ''; // Default XAMPP password is empty

try {
    // Establish a PDO instance with connection parameters
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Set PDO error mode to Exception for robust error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Prevent emulation of prepared statements (ensures native database preparation for high security)
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
} catch (PDOException $e) {
    // If connection fails, output error in JSON format and terminate safely
    header('Content-Type: application/json');
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed: " . $e->getMessage()
    ]);
    exit;
}
?>`;

const SIGNUP_PHP = `<?php
/**
 * signup.php
 * Handles new user account registrations securely using PDO prepared statements
 * Automatically hashes user passwords with bcrypt ($2y$ format)
 */

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

// Read inputs
$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_SPECIAL_CHARS);
$password = $_POST['password'] ?? '';

// Validate inputs
if (!$name || !$email || !$phone || !$password) {
    echo json_encode(["success" => false, "message" => "All fields are required."]);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(["success" => false, "message" => "Password must be at least 6 characters long."]);
    exit;
}

// Indian mobile validation
$cleanPhone = preg_replace('/[\s-]/', '', $phone);
if (!preg_match('/^(?:\+91|91)?[6789]\d{9}$/', $cleanPhone)) {
    echo json_encode(["success" => false, "message" => "Please enter a valid 10-digit Indian phone number."]);
    exit;
}

try {
    // Check if email already exists
    $check_stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
    $check_stmt->execute([':email' => $email]);
    if ($check_stmt->fetch()) {
        echo json_encode(["success" => false, "message" => "An account with this email already exists."]);
        exit;
    }

    // Hash the password securely using Bcrypt (native standard PHP hashing)
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert user row
    $sql = "INSERT INTO users (name, email, phone, password, role) VALUES (:name, :email, :phone, :password, 'customer')";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':name' => $name,
        ':email' => $email,
        ':phone' => $phone,
        ':password' => $hashed_password
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Account successfully created! You may now sign in."
    ]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database Error: " . $e->getMessage()]);
}
?>`;

const LOGIN_PHP = `<?php
/**
 * login.php
 * Handles user and admin authentication
 * Employs safe prepared statements and verifies secure password hashes
 */

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$password = $_POST['password'] ?? '';

if (!$email || !$password) {
    echo json_encode(["success" => false, "message" => "Email and password are required."]);
    exit;
}

try {
    // Fetch user details safely
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Success: Don't return password hash back to user
        unset($user['password']);
        echo json_encode([
            "success" => true,
            "message" => "Login successful!",
            "user" => $user
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Invalid email or password combination."
        ]);
    }

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database Error: " . $e->getMessage()]);
}
?>`;

const BOOK_PHP = `<?php
/**
 * book.php
 * Handles booking form submission securely
 * Prevents SQL Injection using PDO Prepared Statements
 */

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

// Extract inputs
$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
$phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_SPECIAL_CHARS);
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$people = filter_input(INPUT_POST, 'people', FILTER_VALIDATE_INT);
$date = filter_input(INPUT_POST, 'date', FILTER_SANITIZE_SPECIAL_CHARS);
$time = filter_input(INPUT_POST, 'time', FILTER_SANITIZE_SPECIAL_CHARS);
$table_location = filter_input(INPUT_POST, 'table_location', FILTER_SANITIZE_SPECIAL_CHARS) ?? 'Maharajah Booth';

if (!$name || !$phone || !$email || !$people || !$date || !$time) {
    echo json_encode(["success" => false, "message" => "All fields are required."]);
    exit;
}

// Validate Indian phone format
$cleanPhone = preg_replace('/[\s-]/', '', $phone);
if (!preg_match('/^(?:\+91|91)?[6789]\d{9}$/', $cleanPhone)) {
    echo json_encode(["success" => false, "message" => "Please enter a valid 10-digit Indian phone number."]);
    exit;
}

if ($people < 1 || $people > 10) {
    echo json_encode(["success" => false, "message" => "Guests count must be between 1 and 10."]);
    exit;
}

$today = date('Y-m-d');
if ($date < $today) {
    echo json_encode(["success" => false, "message" => "You cannot reserve a table for a past date."]);
    exit;
}

try {
    $table_number = rand(1, 18);
    $sql = "INSERT INTO bookings (name, phone, email, people, date, time, table_location, table_number) 
            VALUES (:name, :phone, :email, :people, :date, :time, :table_location, :table_number)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':name' => $name,
        ':phone' => $phone,
        ':email' => $email,
        ':people' => $people,
        ':date' => $date,
        ':time' => $time,
        ':table_location' => $table_location,
        ':table_number' => $table_number
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Reservation successfully booked! Table #$table_number in $table_location is reserved for you.",
        "booking_id" => $pdo->lastInsertId()
    ]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database Error: " . $e->getMessage()]);
}
?>`;

const README_MD = `# Shahi Rasoi Table Booking & Auth System (XAMPP Setup Guide)

Follow these steps to run the complete Indian table booking, Login, Signup and admin system locally using **VS Code** and **XAMPP**.

---

### Step 1: Download & Install XAMPP
1. Download XAMPP from: [https://www.apachefriends.org/index.html](https://www.apachefriends.org/index.html).
2. Install Apache and MySQL modules.

### Step 2: Start XAMPP Server Control Panel
1. Open XAMPP and click **Start** next to **Apache** and **MySQL**.

### Step 3: Create Project Directory in htdocs
1. Create a folder named \`restaurant_india\` in htdocs directory:
   - **Windows**: \`C:\\xampp\\htdocs\\restaurant_india\`
   - **macOS**: \`/Applications/XAMPP/xamppfiles/htdocs/restaurant_india\`

### Step 4: Paste code files
1. Open VS Code, open the folder \`restaurant_india\`, and create these files from the Exporter tabs:
   - \`db_connect.php\`
   - \`signup.php\`
   - \`login.php\`
   - \`book.php\`
   - \`database.sql\`

### Step 5: Setup SQL Database in phpMyAdmin
1. Open [http://localhost/phpmyadmin/](http://localhost/phpmyadmin/).
2. Create a database named \`restaurant_india\`.
3. Go to the **SQL** tab, paste the code from \`database.sql\`, and click **Go**.

### Step 6: Verify Auth Accounts
* **Default Admin account**: \`abhayrana4409@gmail.com\` with password \`admin123\`
* **Default Customer account**: \`arjun@example.com\` with password \`customer123\`
* You can test registering new accounts with real passwords; they are instantly encrypted inside the database safely!`;

const EXPORT_FILES: CodeFile[] = [
  { name: "README.md", language: "markdown", content: README_MD, description: "Detailed, step-by-step setup manual to run this full-stack PHP app with XAMPP & VS Code." },
  { name: "database.sql", language: "sql", content: DATABASE_SQL, description: "MySQL database schema to create tables 'users' and 'bookings' with encrypted passwords." },
  { name: "db_connect.php", language: "php", content: DB_CONNECT_PHP, description: "Secure PDO database connection file." },
  { name: "signup.php", language: "php", content: SIGNUP_PHP, description: "Secures user sign ups using bcrypt password hashing." },
  { name: "login.php", language: "php", content: LOGIN_PHP, description: "Secures user logins using password verification algorithms." },
  { name: "book.php", language: "php", content: BOOK_PHP, description: "Creates bookings securely." },
];

export default function DevCenter({ bookings, executedQueries }: DevCenterProps) {
  const [activeFile, setActiveFile] = useState<number>(0);
  const [copied, setCopied] = useState(false);
  const sqlConsoleOpen = true;

  // SQL Terminal Sandbox states
  const [sandboxQuery, setSandboxQuery] = useState("SELECT * FROM bookings;");
  const [sandboxOutput, setSandboxOutput] = useState<string>("");
  const [isLoadingSandbox, setIsLoadingSandbox] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(EXPORT_FILES[activeFile].content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const executeSandbox = () => {
    setIsLoadingSandbox(true);
    
    setTimeout(() => {
      const q = sandboxQuery.trim().toLowerCase();
      
      if (q.startsWith("select * from bookings")) {
        if (bookings.length === 0) {
          setSandboxOutput("Empty set (0 records in table bookings).");
        } else {
          const header = "| id | name            | email                 | phone         | people | date       | time  |\n|----|-----------------|-----------------------|---------------|--------|------------|-------|";
          const rows = bookings.map(b => 
            `| ${String(b.id).padEnd(2)} | ${b.name.padEnd(15).substring(0, 15)} | ${b.email.padEnd(21).substring(0, 21)} | ${b.phone.padEnd(13).substring(0, 13)} | ${String(b.people).padEnd(6)} | ${b.date} | ${b.time.substring(0, 5)} |`
          ).join("\n");
          setSandboxOutput(`${header}\n${rows}\n\n${bookings.length} rows in set (0.00 sec)`);
        }
      } else if (q.startsWith("select * from users")) {
        const header = "| id | name            | email                 | phone         | role      |\n|----|-----------------|-----------------------|---------------|-----------|";
        const rows = [
          `| 1  | Abhay           | abhayrana4409@gmail.com | +919876543210 | admin     |`,
          `| 2  | Arjun Sharma    | arjun@example.com       | +919876543210 | customer  |`
        ].join("\n");
        setSandboxOutput(`${header}\n${rows}\n\n2 rows in set (0.00 sec)`);
      } else if (q.includes("or 1=1") || q.includes("' or '1'='1")) {
        setSandboxOutput(`SQL SYNTAX ERROR / BLOCKED: Prepared statement compilation detected an SQL Injection pattern!\n\nParameters: "${sandboxQuery}"\nResult: Parameter bound as string successfully. Statement treated safely without code executing.\nNo vulnerabilities found!`);
      } else {
        setSandboxOutput(`Executed successfully:\nQuery: "${sandboxQuery}"\nStatus: Secure Sandbox compiled the statement. (Use 'SELECT * FROM bookings;' or 'SELECT * FROM users;' to list active mock database elements!)`);
      }
      setIsLoadingSandbox(false);
    }, 450);
  };

  return (
    <div className="bg-[#041510] text-[#fbf8f3] min-h-screen py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Title Block */}
        <div className="text-center max-w-3xl mx-auto mb-8">
          <div className="inline-flex items-center space-x-2 bg-[#d97706]/10 border border-[#d97706]/20 text-[#f59e0b] px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-4">
            <Database className="h-4 w-4" />
            <span>Developer Center & Sandbox Suite</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white">Full-Stack PHP/MySQL Exporter</h1>
          <p className="text-slate-400 text-sm sm:text-base mt-2 font-light">
            Need to submit this as a fully functional project for university, school, or portfolio? Download our premium XAMPP-ready PHP codebase with MySQL tables and built-in SQL Injection security!
          </p>
        </div>

        {/* METRICS ROW */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* FILE TABS (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            <div className="bg-[#02110c] border border-[#d97706]/10 p-4 rounded-2xl">
              <h3 className="text-xs font-bold uppercase text-slate-400 mb-3 tracking-widest flex items-center space-x-1.5">
                <FileCode className="h-4 w-4" />
                <span>Files Included (XAMPP Suite)</span>
              </h3>
              
              <div className="space-y-2">
                {EXPORT_FILES.map((file, idx) => (
                  <button
                    key={file.name}
                    onClick={() => setActiveFile(idx)}
                    className={`w-full flex items-start text-left p-3 rounded-xl border transition-all cursor-pointer ${
                      activeFile === idx
                        ? "bg-[#d97706]/10 border-[#d97706] text-[#f59e0b]"
                        : "bg-[#041510] border-[#07241b] text-slate-300 hover:bg-[#07241b]"
                    }`}
                  >
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs sm:text-sm font-mono">{file.name}</span>
                        <span className="text-[9px] uppercase font-bold tracking-widest bg-[#02110c] text-slate-400 px-1.5 py-0.5 rounded border border-[#d97706]/10">
                          {file.language}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 line-clamp-1 leading-normal font-light">
                        {file.description}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Educational SQL prepared statement card */}
            <div className="bg-[#02110c] border border-[#d97706]/10 p-5 rounded-2xl space-y-3">
              <h4 className="font-bold text-white text-xs sm:text-sm flex items-center space-x-2">
                <Info className="h-4 w-4 text-[#f59e0b]" />
                <span>How We Prevent SQL Injection</span>
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed font-light">
                Normally, inserting values directly into SQL commands allows users to inject malicious operations like <strong className="text-amber-500 font-mono">1' OR '1'='1</strong>. 
              </p>
              <p className="text-xs text-slate-400 leading-relaxed font-light">
                Our PHP code forces MySQL to use <strong className="text-white font-semibold">Prepared Statements</strong>, which forces parameters to compile only as pure data, entirely neutralizing hacking scripts.
              </p>
            </div>
          </div>

          {/* CODE DISPLAY PANEL (8 cols) */}
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-[#02110c] border border-[#d97706]/10 rounded-2xl overflow-hidden shadow-xl">
              {/* Toolbar */}
              <div className="bg-[#041510] px-5 py-4 border-b border-[#07241b] flex justify-between items-center">
                <div className="flex items-center space-x-3">
                  <div className="h-3 w-3 rounded-full bg-rose-500" />
                  <div className="h-3 w-3 rounded-full bg-amber-500" />
                  <div className="h-3 w-3 rounded-full bg-emerald-500" />
                  <span className="text-xs font-mono text-slate-400 font-bold tracking-wider pl-2">
                    {EXPORT_FILES[activeFile].name}
                  </span>
                </div>
                <button
                  onClick={handleCopy}
                  className="bg-[#02110c] border border-[#d97706]/20 hover:border-[#d97706]/40 hover:bg-[#07241b] text-slate-300 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>

              {/* Code Box */}
              <pre className="p-6 bg-[#041510] font-mono text-[11px] sm:text-xs text-slate-300 overflow-x-auto h-[55vh] leading-relaxed selection:bg-[#d97706] selection:text-[#041510]">
                <code>{EXPORT_FILES[activeFile].content}</code>
              </pre>
            </div>
          </div>

        </div>

        {/* INTERACTIVE LIVE BACKEND SQL SIMULATOR (CONSOLE) */}
        {sqlConsoleOpen && (
          <div className="bg-[#02110c] border border-[#d97706]/10 rounded-3xl overflow-hidden shadow-2xl">
            <div className="bg-[#041510] px-6 py-5 border-b border-[#07241b] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-center space-x-3">
                <div className="bg-[#d97706]/10 border border-[#d97706]/20 text-[#f59e0b] p-2.5 rounded-xl">
                  <Terminal className="h-5 w-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Interactive SQL & Prepared Statement Simulator</h3>
                  <p className="text-xs text-slate-400 font-light">Interact with the local simulated MySQL database using SQL strings.</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2.5">
                <button
                  onClick={() => setSandboxQuery("SELECT * FROM bookings;")}
                  className="bg-[#02110c] border border-[#d97706]/10 text-slate-300 hover:bg-[#07241b] px-3 py-1.5 rounded-xl text-xs font-mono cursor-pointer"
                >
                  SELECT BOOKINGS
                </button>
                <button
                  onClick={() => setSandboxQuery("SELECT * FROM users;")}
                  className="bg-[#02110c] border border-[#d97706]/10 text-slate-300 hover:bg-[#07241b] px-3 py-1.5 rounded-xl text-xs font-mono cursor-pointer"
                >
                  SELECT USERS
                </button>
                <button
                  onClick={() => setSandboxQuery("SELECT * FROM bookings WHERE email = 'hacker' OR 1=1 --';")}
                  className="bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 px-3 py-1.5 rounded-xl text-xs font-mono cursor-pointer"
                >
                  TEST INJECTION
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12">
              {/* Input Area (7 cols) */}
              <div className="lg:col-span-7 p-6 border-r border-[#07241b] space-y-4">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Query Console Input</span>
                  <div className="relative">
                    <span className="absolute left-3 top-2 text-slate-500 font-mono text-xs select-none">mysql&gt;</span>
                    <input
                      type="text"
                      value={sandboxQuery}
                      onChange={(e) => setSandboxQuery(e.target.value)}
                      className="w-full bg-[#041510] font-mono text-xs text-white border border-[#d97706]/15 rounded-xl py-2 pl-16 pr-4 focus:outline-none focus:border-[#d97706]"
                    />
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-1.5 text-[10px] text-slate-500">
                    <BookOpen className="h-4 w-4" />
                    <span>Run queries to inspect your database table structures in real-time.</span>
                  </div>
                  <button
                    onClick={executeSandbox}
                    disabled={isLoadingSandbox}
                    className="bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-[#041510] font-black px-4 py-2 rounded-xl text-xs flex items-center space-x-1.5 shadow-md cursor-pointer"
                  >
                    {isLoadingSandbox ? (
                      <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Play className="h-3.5 w-3.5" />
                    )}
                    <span>Execute SQL Query</span>
                  </button>
                </div>

                {/* Submited SQL history */}
                <div className="pt-4 border-t border-[#07241b]">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Simulated SQL Query History</span>
                  <div className="max-h-36 overflow-y-auto space-y-2 pr-1.5 scrollbar-thin">
                    {executedQueries.length > 0 ? (
                      executedQueries.map((log, index) => (
                        <div key={index} className="bg-[#041510] p-2.5 rounded-lg border border-[#02110c] font-mono text-[9px] text-amber-500 overflow-x-auto whitespace-pre">
                          {log}
                        </div>
                      ))
                    ) : (
                      <p className="text-[10px] text-slate-500 italic">No queries executed yet. Make a table reservation to populate SQL history logs.</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Output Display Terminal (5 cols) */}
              <div className="lg:col-span-5 bg-[#041510] p-6 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">MySQL Server Terminal Output</span>
                  {sandboxOutput ? (
                    <pre className="font-mono text-[10px] text-emerald-400 overflow-x-auto whitespace-pre leading-relaxed select-all">
                      <code>{sandboxOutput}</code>
                    </pre>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-10 text-slate-600 text-center">
                      <AlertCircle className="h-8 w-8 mb-2 animate-bounce" />
                      <p className="text-xs font-mono">Terminal Standby</p>
                      <p className="text-[10px] mt-0.5">Click 'Execute SQL Query' to see outputs.</p>
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-[#02110c] flex justify-between items-center text-[9px] text-slate-500">
                  <span>Engine: InnoDB (UTF-8)</span>
                  <span>v8.0.28 Community Server</span>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
