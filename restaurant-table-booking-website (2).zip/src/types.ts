export interface Booking {
  id: number;
  name: string;
  email: string;
  phone: string; // Indian format
  people: number;
  date: string;
  time: string;
  tableLocation: string; // 'Royal Durbar' | 'Haveli Courtyard' | 'Maharajah Booth' | 'Saffron Terrace'
  tableNumber: number;
  createdAt: string;
}

export interface MenuItem {
  id: number;
  name: string;
  price: number; // in INR (₹)
  category: 'starters' | 'mains' | 'desserts' | 'drinks' | 'streetfood';
  description: string;
  image?: string;
  tag?: string;
}

export interface Testimonial {
  id: number;
  name: string;
  rating: number;
  comment: string;
  date: string;
  role: string;
}

export interface CodeFile {
  name: string;
  language: string;
  content: string;
  description: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: 'customer' | 'admin';
  createdAt: string;
}
